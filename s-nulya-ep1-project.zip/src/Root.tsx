import React from 'react';
import {Composition} from 'remotion';
import {SNulya1, SNulya1TestHook, SNulya1TestHands} from './sn1/Episode';
import {TOTAL, FPS, W, H} from './sn1/story';

/** Сериал «С нуля». Композиции «Последнего автобуса» живут в отдельном проекте и сюда не подключены. */
export const Root: React.FC = () => (
  <>
    <Composition id="SNulyaEp1" component={SNulya1} durationInFrames={TOTAL} fps={FPS} width={W} height={H} />
    <Composition id="SNulyaEp1TestHook" component={SNulya1TestHook} durationInFrames={240} fps={FPS} width={W} height={H} />
    <Composition id="SNulyaEp1TestHands" component={SNulya1TestHands} durationInFrames={330} fps={FPS} width={W} height={H} />
  </>
);
