import React from 'react';
import {useCurrentFrame} from 'remotion';
import {SKIN, clamp} from '../common';
import {C, CI, sm, win, revealByWords} from './story';
import {PAL, Icon, Artwork} from './props';

export const SW = 560, SH = 1140; // экран телефона (локальные координаты)
const F = 'Manrope';

const T: React.FC<{x: number; y: number; s: number; w?: number; c?: string; a?: 'start' | 'middle' | 'end'; o?: number; children: React.ReactNode}> = ({x, y, s, w = 700, c = PAL.ink, a = 'start', o = 1, children}) => (
  <text x={x} y={y} fontFamily={F} fontWeight={w} fontSize={s} fill={c} textAnchor={a} opacity={o}>{children}</text>
);

const StatusBar: React.FC<{dark?: boolean}> = ({dark}) => (
  <g>
    <rect x={SW / 2 - 60} y={14} width={120} height={30} rx={15} fill="#0c0f18" />
    {[0, 1, 2, 3].map((i) => <rect key={i} x={SW - 120 + i * 9} y={34 - i * 5} width={6} height={8 + i * 5} rx={2} fill={dark ? '#fff' : PAL.ink} />)}
    <rect x={SW - 72} y={22} width={40} height={20} rx={5} fill="none" stroke={dark ? '#fff' : PAL.ink} strokeWidth={2.5} />
    <rect x={SW - 69} y={25} width={18} height={14} rx={3} fill={dark ? '#fff' : PAL.ink} />
  </g>
);

/** Крупный план телефона в руке. Рука снизу справа, большой палец может «нажимать» (thumb: [x,y] в координатах экрана или null). */
export const PhoneCU: React.FC<{children: React.ReactNode; thumb?: [number, number] | null; press?: number; bg?: 'day' | 'evening' | 'night'; y?: number; dark?: boolean}> = ({children, thumb = null, press = 0, bg = 'day', y = 820, dark = false}) => {
  const frame = useCurrentFrame();
  const bgc = {day: ['#f3e9d6', '#e7d8bc'], evening: ['#f6c79a', '#e8a978'], night: ['#273560', '#1b2546']}[bg];
  const sx = 540 - SW / 2, sy = y - SH / 2;
  return (
    <g>
      <rect width={1080} height={1920} fill={bgc[0]} />
      {/* размытый фон комнаты */}
      <g filter="url(#blur18)">
        <rect x={-100} y={200} width={500} height={700} rx={30} fill={bg === 'night' ? '#3a4f8f' : '#bfe3ff'} opacity={0.6} />
        <circle cx={900} cy={420} r={160} fill={bg === 'night' ? '#ffd98f' : PAL.greenSoft} opacity={0.55} />
        <rect x={-100} y={1450} width={1300} height={600} fill={bgc[1]} />
        {[[180, 1300], [820, 1200], [950, 900]].map(([x, yy], i) => <circle key={i} cx={x + Math.sin(frame / 50 + i) * 8} cy={yy} r={90} fill={bg === 'night' ? '#ffcf7a' : '#fff6dc'} opacity={0.4} />)}
      </g>
      {/* рукав и ладонь, держащая телефон снизу */}
      <path d="M560 1480 L790 1420 L1160 1960 L760 1980Z" fill="#5470a6" />
      <path d="M700 1450 L790 1420 L1160 1960 L1020 1970Z" fill="#3a5287" opacity={0.45} />
      <path d="M540 1400 L800 1380 L830 1500 L560 1520Z" fill="#445f95" />
      <path d={`M${sx + 40} ${sy + SH - 120} Q${sx - 10} ${sy + SH + 60} ${sx + 180} ${sy + SH + 110} L${sx + 470} ${sy + SH + 90} Q${sx + SW + 40} ${sy + SH + 20} ${sx + SW - 10} ${sy + SH - 140}Z`} fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
      {/* корпус */}
      <rect x={sx - 24} y={sy - 24} width={SW + 48} height={SH + 48} rx={78} fill="#1d2232" />
      <rect x={sx - 18} y={sy - 18} width={SW + 36} height={SH + 36} rx={72} fill="none" stroke="#59627d" strokeWidth={4} />
      <clipPath id="phScr"><rect x={sx} y={sy} width={SW} height={SH} rx={56} /></clipPath>
      <g clipPath="url(#phScr)">
        <g transform={`translate(${sx} ${sy})`}>
          <rect width={SW} height={SH} fill={dark ? '#141a2c' : '#f8f6f1'} />
          {children}
          <StatusBar dark={dark} />
        </g>
      </g>
      {/* пальцы по краям корпуса */}
      <rect x={sx - 52} y={sy + SH - 360} width={56} height={150} rx={28} fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
      {[0, 1, 2].map((i) => <rect key={i} x={sx + SW - 6} y={sy + SH - 420 + i * 78} width={66} height={64} rx={30} fill={SKIN} stroke="#d49a6e" strokeWidth={4} />)}
      {/* вторая рука: указательный палец нажимает на экран (рука входит снизу слева) */}
      {thumb && (
        <g transform={`translate(${sx + thumb[0]} ${sy + thumb[1] + 8 * press}) rotate(18)`}>
          <path d="M-140 330 L120 330 L230 1500 L-300 1500Z" fill="#5470a6" />
          <rect x={-150} y={300} width={280} height={80} rx={30} fill="#445f95" />
          <path d="M-120 150 Q-150 300 -100 340 L110 340 Q150 260 110 140 Q60 110 -10 120Z" fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
          {[0, 1, 2].map((i) => <rect key={i} x={-110 + i * 0} y={150 + i * 50} width={70} height={46} rx={22} fill={SKIN} stroke="#d49a6e" strokeWidth={3} transform={`translate(${i * 6} 0)`} />)}
          <rect x={-30} y={-6} width={62} height={190} rx={31} fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
          <ellipse cx={1} cy={18} rx={20} ry={24} fill="#f9dcbd" stroke="#e3b48c" strokeWidth={2} />
          <path d="M70 170 Q130 160 140 220 Q120 250 90 240" fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
        </g>
      )}
      {thumb && press > 0.3 && <circle cx={sx + thumb[0]} cy={sy + thumb[1]} r={30 + 20 * press} fill="#ffffff" opacity={0.3 * press} />}
    </g>
  );
};

const Card: React.FC<{x: number; y: number; w: number; h: number; c?: string; r?: number; o?: number; stroke?: string; children?: React.ReactNode}> = ({x, y, w, h, c = '#fff', r = 26, o = 1, stroke, children}) => (
  <g opacity={o}>
    <rect x={x} y={y + 6} width={w} height={h} rx={r} fill="#000" opacity={0.06} />
    <rect x={x} y={y} width={w} height={h} rx={r} fill={c} stroke={stroke} strokeWidth={stroke ? 3 : 0} />
    {children}
  </g>
);

/** 1. Банк: баланс «300 ₽» + напоминание об оплате */
export const BankScreen: React.FC<{t: number}> = ({t}) => {
  const rem = sm(t, C.three - 0.35, C.three + 0.05);
  const pulse = 1 + 0.03 * Math.sin(Math.max(0, t - C.balance) * 5) * (t > C.balance && t < C.balance + 1.5 ? 1 : 0);
  return (
    <g>
      <rect width={SW} height={SH} fill="#f8f6f1" />
      <T x={36} y={130} s={34} w={800}>Мой банк</T>
      <circle cx={SW - 60} cy={118} r={26} fill={PAL.greenSoft} />
      <Card x={30} y={180} w={SW - 60} h={300} c={PAL.blue} r={34}>
        <rect x={30} y={180} width={SW - 60} height={300} rx={34} fill="url(#cardSheen)" opacity={0.3} />
        <T x={64} y={240} s={26} w={600} c="#dce8ff">Основная карта</T>
        <g transform={`translate(${SW / 2} 395) scale(${pulse})`}>
          <T x={0} y={0} s={150} w={800} c="#fff" a="middle">300 ₽</T>
        </g>
        <T x={64} y={455} s={24} w={600} c="#dce8ff">Доступно</T>
      </Card>
      <g opacity={0.5}>
        {['Перевести', 'Оплатить', 'История'].map((l, i) => (
          <g key={i} transform={`translate(${70 + i * 160} 560)`}>
            <circle r={38} fill="#e9eef7" /><T x={0} y={75} s={22} w={600} a="middle" c="#5b6785">{l}</T>
          </g>
        ))}
      </g>
      {/* напоминание сверху */}
      <g transform={`translate(0 ${-260 * (1 - rem)})`} opacity={rem}>
        <Card x={20} y={56} w={SW - 40} h={210} c="#ffffff" r={30} stroke="#f2c9a8">
          <g transform="translate(76 128)"><Icon kind="calendar" size={70} /></g>
          <T x={130} y={110} s={24} w={700} c="#8a93a8">Напоминание</T>
          <T x={130} y={160} s={36} w={800} c={PAL.ink}>ОПЛАТА КВАРТИРЫ —</T>
          <T x={130} y={212} s={44} w={800} c="#e2603a">ЧЕРЕЗ 3 ДНЯ</T>
        </Card>
      </g>
    </g>
  );
};

/** 2. История операций: снизу вверх — зарплата, еда, одежда, еда, подписка (без сумм) */
const HIST = [
  {k: 'sub', title: 'Подписка', note: 'автопродление', cue: 'sub'},
  {k: 'food', title: 'Доставка еды', note: 'заказ', cue: 'food2'},
  {k: 'clothes', title: 'Одежда', note: 'покупка', cue: 'clothes'},
  {k: 'food', title: 'Доставка еды', note: 'заказ', cue: 'food1'},
  {k: 'salary', title: 'ЗАРПЛАТА', note: '2 НЕДЕЛИ НАЗАД', cue: 'salary'},
] as const;
export const HistoryScreen: React.FC<{t: number}> = ({t}) => {
  const scroll = 0;
  return (
    <g>
      <rect width={SW} height={SH} fill="#f8f6f1" />
      <T x={36} y={130} s={36} w={800}>История</T>
      <T x={36} y={176} s={24} w={600} c="#8a93a8">Куда ушли деньги</T>
      <g transform={`translate(0 ${scroll})`}>
        {HIST.map((h, i) => {
          const y = 230 + i * 168;
          const on = t >= C[h.cue] - 0.1;
          const isSal = h.k === 'salary';
          const hl = isSal ? sm(t, C.salary - 0.2, C.salary + 0.3) : sm(t, C[h.cue] - 0.15, C[h.cue] + 0.2);
          return (
            <Card key={i} x={24} y={y} w={SW - 48} h={146} c={isSal ? '#e6f7ee' : '#fff'} r={26} stroke={hl > 0.5 ? (isSal ? PAL.green : '#f2b632') : undefined}>
              <g transform={`translate(${86} ${y + 73})`} opacity={on || isSal ? 1 : 0.45}><Icon kind={h.k as any} size={78} /></g>
              <T x={150} y={y + 64} s={isSal ? 34 : 32} w={800} o={on || isSal ? 1 : 0.5}>{h.title}</T>
              <T x={150} y={y + 110} s={isSal ? 30 : 24} w={isSal ? 800 : 600} c={isSal ? PAL.greenDeep : '#8a93a8'} o={on || isSal ? 1 : 0.5}>{h.note}</T>
            </Card>
          );
        })}
      </g>
    </g>
  );
};

/** 3. Подписка: забыта → отключена */
export const SubScreen: React.FC<{t: number; mode: 'forgot' | 'cancel'}> = ({t, mode}) => {
  const off = mode === 'cancel' ? sm(t, C.cancel + 0.6, C.cancel + 0.85) : 0;
  const done = mode === 'cancel' ? sm(t, C.cancel + 1.0, C.cancel + 1.3) : 0;
  return (
    <g>
      <rect width={SW} height={SH} fill="#f8f6f1" />
      <T x={36} y={130} s={36} w={800}>Подписки</T>
      <Card x={24} y={190} w={SW - 48} h={420} c="#fff" r={30}>
        <g transform="translate(110 290)"><Icon kind="sub" size={120} /></g>
        <T x={200} y={278} s={38} w={800}>Подписка</T>
        <T x={200} y={322} s={24} w={600} c="#8a93a8">видео и музыка</T>
        <line x1={50} y1={390} x2={SW - 74} y2={390} stroke="#eee6d8" strokeWidth={3} />
        <T x={56} y={460} s={30} w={700}>Автопродление</T>
        <g transform={`translate(${SW - 150} 448)`}>
          <rect x={-10} y={-26} width={96} height={52} rx={26} fill={off > 0.5 ? '#d7dce6' : PAL.green} />
          <circle cx={off > 0.5 ? 16 : 60} cy={0} r={21} fill="#fff" />
        </g>
        {mode === 'forgot' && (
          <g opacity={sm(t, C.forgot - 0.3, C.forgot)}>
            <rect x={56} y={505} width={340} height={64} rx={32} fill="#fff1dc" />
            <T x={226} y={548} s={28} w={800} c="#d9822b" a="middle">НЕ ИСПОЛЬЗУЕТСЯ</T>
          </g>
        )}
      </Card>
      {mode === 'cancel' && done > 0 && (
        <Card x={24} y={650} w={SW - 48} h={130} c="#e6f7ee" r={30} o={done}>
          <circle cx={90} cy={715} r={30} fill={PAL.green} />
          <path d="M76 715 l10 11 l20 -22" stroke="#fff" strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" />
          <T x={140} y={728} s={32} w={800} c={PAL.greenDeep}>ПОДПИСКА ОТКЛЮЧЕНА</T>
        </Card>
      )}
    </g>
  );
};

/** 4. Заметки: список платежей без выдуманных сумм; итог скрыт */
const NOTES = ['Квартира', 'Телефон и интернет', 'Проезд', 'Подписка'];
export const NotesScreen: React.FC<{t: number}> = ({t}) => {
  const typed = clamp((t - C.wrote) / (C.sum - C.wrote - 0.2));
  const total = sm(t, C.sum - 0.1, C.sum + 0.4);
  const caretOn = Math.floor(t * 2.5) % 2 === 0;
  return (
    <g>
      <rect width={SW} height={SH} fill="#fffbeF" />
      <rect width={SW} height={SH} fill="#fff9ea" />
      <T x={36} y={130} s={26} w={700} c="#d9a21a">‹ Заметки</T>
      <T x={36} y={210} s={38} w={800}>Оплатить</T>
      <T x={36} y={258} s={38} w={800}>в ближайшие дни</T>
      {NOTES.map((n, i) => {
        const a = clamp(typed * NOTES.length - i);
        const shown = n.slice(0, Math.round(n.length * a));
        return (
          <g key={i}>
            <circle cx={52} cy={338 + i * 82} r={9} fill={a > 0 ? PAL.ink : 'none'} />
            <T x={78} y={350 + i * 82} s={34} w={600}>{shown}{a > 0 && a < 1 && caretOn ? '|' : ''}</T>
          </g>
        );
      })}
      <line x1={36} y1={700} x2={SW - 36} y2={700} stroke="#e9dcb8" strokeWidth={3} opacity={total} />
      <g opacity={total}>
        <T x={36} y={770} s={40} w={800}>ИТОГО:</T>
        <g filter="url(#blur6)">{[0, 1, 2].map((i) => <rect key={i} x={230 + i * 92} y={728} width={78} height={56} rx={14} fill="#c9bfa6" />)}</g>
        <T x={36} y={850} s={26} w={600} c="#c0571f">больше, чем я ожидал</T>
      </g>
    </g>
  );
};

/** 5. Звонок хозяину квартиры */
export const CallScreen: React.FC<{t: number}> = ({t}) => (
  <g>
    <rect width={SW} height={SH} fill="#20304f" />
    <circle cx={SW / 2} cy={330} r={110} fill="#3c5a92" />
    <T x={SW / 2} y={360} s={96} w={800} c="#fff" a="middle">Х</T>
    <T x={SW / 2} y={530} s={40} w={800} c="#fff" a="middle">Хозяин квартиры</T>
    <T x={SW / 2} y={584} s={28} w={600} c="#b9c8e6" a="middle">{'Вызов' + '.'.repeat(1 + (Math.floor(t * 2) % 3))}</T>
    {[0, 1, 2].map((k) => <circle key={k} cx={SW / 2} cy={330} r={110 + ((t * 60 + k * 40) % 120)} fill="none" stroke="#9fc0ff" strokeWidth={3} opacity={0.5 * (1 - ((t * 60 + k * 40) % 120) / 120)} />)}
    <circle cx={SW / 2} cy={960} r={52} fill="#e35d5b" />
    <rect x={SW / 2 - 28} y={952} width={56} height={16} rx={8} fill="#fff" transform={`rotate(-20 ${SW / 2} 960)`} />
  </g>
);

/** 6. Новый срок: «ЧЕРЕЗ 3 ДНЯ» зачёркнуто → «ЕСТЬ 7 ДНЕЙ» */
export const DeadlineScreen: React.FC<{t: number}> = ({t}) => {
  const strike = sm(t, C.onlyWeek - 0.1, C.onlyWeek + 0.4);
  const neu = sm(t, C.onlyWeek + 0.5, C.onlyWeek + 0.9);
  const dots = clamp((t - C.seven + 0.2) / 1.2);
  return (
    <g>
      <rect width={SW} height={SH} fill="#f8f6f1" />
      <T x={36} y={130} s={36} w={800}>Напоминания</T>
      <Card x={24} y={180} w={SW - 48} h={560} c="#fff" r={32}>
        <g transform="translate(96 268)"><Icon kind="home" size={90} /></g>
        <T x={170} y={258} s={36} w={800}>Оплата квартиры</T>
        <T x={170} y={300} s={24} w={600} c="#8a93a8">хозяин согласился подождать</T>
        <g opacity={1 - 0.45 * neu}>
          <T x={56} y={420} s={48} w={800} c="#e2603a">ЧЕРЕЗ 3 ДНЯ</T>
          <rect x={52} y={400} width={330 * strike} height={7} rx={3} fill={PAL.ink} />
        </g>
        <g opacity={neu} transform={`translate(0 ${(1 - neu) * 20})`}>
          <rect x={46} y={470} width={SW - 140} height={96} rx={24} fill="#e6f7ee" />
          <T x={(SW - 48) / 2 + 24} y={536} s={58} w={800} c={PAL.greenDeep} a="middle">ЕСТЬ 7 ДНЕЙ</T>
          {Array.from({length: 7}).map((_, i) => (
            <circle key={i} cx={92 + i * 60} cy={640} r={20} fill={dots * 7 > i ? PAL.green : '#e9eef4'} stroke={PAL.green} strokeWidth={3} />
          ))}
        </g>
      </Card>
    </g>
  );
};

/** 7. Объявление «огромный заработок» → чат с просьбой оплатить «обучение» */
export const ScamScreen: React.FC<{t: number}> = ({t}) => {
  const chat = sm(t, C.perfect + 0.35, C.perfect + 0.75);
  const m1 = sm(t, C.until + 0.4, C.until + 0.7), m2 = sm(t, C.transfer - 0.6, C.transfer - 0.3);
  const bal = win(t, C.look300 - 0.2, C.look300 + 0.2, C.closeChat + 0.3, C.closeChat + 0.6);
  const closeA = sm(t, C.closeChat + 0.2, C.closeChat + 0.65);
  const frame = useCurrentFrame();
  return (
    <g>
      <rect width={SW} height={SH} fill="#f8f6f1" />
      <g transform={`translate(${-SW * chat} 0)`}>
        <T x={36} y={130} s={36} w={800}>Подработка</T>
        <rect x={24} y={160} width={SW - 48} height={60} rx={30} fill="#eceae4" />
        <T x={60} y={200} s={24} w={600} c="#8a93a8">поиск: подработка</T>
        <Card x={24} y={250} w={SW - 48} h={520} c="#fff4cf" r={30} stroke="#f2b632">
          {Array.from({length: 7}).map((_, i) => (
            <path key={i} d={`M${60 + ((i * 71) % 420)} ${290 + ((i * 113) % 420)} l6 14 l14 6 l-14 6 l-6 14 l-6 -14 l-14 -6 l14 -6z`} fill="#f2b632" opacity={0.5 + 0.5 * Math.sin(frame / 6 + i)} />
          ))}
          <T x={SW / 2} y={380} s={46} w={800} a="middle" c="#c47a00">ОГРОМНЫЙ</T>
          <T x={SW / 2} y={440} s={46} w={800} a="middle" c="#c47a00">ЗАРАБОТОК</T>
          <rect x={120} y={480} width={SW - 240} height={64} rx={32} fill="#fff" />
          <T x={SW / 2} y={523} s={32} w={800} a="middle">БЕЗ ОПЫТА</T>
          <T x={SW / 2} y={600} s={26} w={600} a="middle" c="#7a6a40">Работа из дома, гибкий график</T>
          <rect x={90} y={660} width={SW - 180} height={76} rx={38} fill={t > C.perfect ? PAL.greenDeep : PAL.green} />
          <T x={SW / 2} y={709} s={30} w={800} a="middle" c="#fff">Откликнуться</T>
        </Card>
      </g>
      <g transform={`translate(${SW * (1 - chat)} ${SH * closeA})`} opacity={1 - closeA}>
        <rect width={SW} height={SH} fill="#eef1f5" />
        <rect width={SW} height={180} fill="#fff" />
        <circle cx={80} cy={124} r={34} fill="#f2b632" />
        <T x={130} y={136} s={30} w={800}>Работодатель</T>
        {m1 > 0 && <Card x={24} y={230} w={400} h={110} c="#fff" r={28} o={m1}><T x={50} y={298} s={30} w={600}>Вы нам подходите!</T></Card>}
        {m2 > 0 && (
          <Card x={24} y={370} w={SW - 70} h={230} c="#fff" r={28} o={m2}>
            <T x={50} y={428} s={30} w={600}>Но сначала нужно</T>
            <T x={50} y={472} s={30} w={600}>оплатить обучение.</T>
            <T x={50} y={516} s={30} w={600}>Переведите деньги</T>
            <T x={50} y={560} s={30} w={600}>на карту.</T>
          </Card>
        )}
        {bal > 0 && (
          <g opacity={bal}>
            <rect x={120} y={660} width={SW - 240} height={92} rx={46} fill={PAL.blue} />
            <T x={SW / 2} y={720} s={40} w={800} c="#fff" a="middle">У меня: 300 ₽</T>
          </g>
        )}
      </g>
      {closeA > 0.6 && <T x={SW / 2} y={560} s={30} w={700} c="#8a93a8" a="middle" o={closeA}>Переписка закрыта</T>}
    </g>
  );
};

/** 8. Объявление кафе */
export const CafeAdScreen: React.FC<{t: number}> = ({t}) => (
  <g>
    <rect width={SW} height={SH} fill="#f8f6f1" />
    <T x={36} y={130} s={36} w={800}>Подработка</T>
    <Card x={24} y={180} w={SW - 48} h={140} c="#fff" r={26} o={0.45}><T x={60} y={262} s={28} w={700} c="#b9a46a">ОГРОМНЫЙ ЗАРАБОТОК…</T></Card>
    <Card x={24} y={350} w={SW - 48} h={520} c="#fff" r={30} stroke={t > C.cafe ? PAL.green : undefined}>
      <g transform="translate(100 450)"><Icon kind="cup" size={100} /></g>
      <T x={180} y={440} s={34} w={800}>Небольшое кафе</T>
      <T x={180} y={482} s={24} w={600} c="#8a93a8">рядом с домом</T>
      <T x={56} y={590} s={30} w={600}>Нужен человек, который</T>
      <T x={56} y={634} s={30} w={600}>поможет оформить</T>
      <T x={56} y={678} s={30} w={600}>фотографии для страницы</T>
      <rect x={56} y={740} width={190} height={56} rx={28} fill="#e6f7ee" />
      <T x={151} y={777} s={24} w={700} c={PAL.greenDeep} a="middle">подработка</T>
    </Card>
  </g>
);

/** 9. Галерея: картинки для друзей, выбор трёх лучших */
export const GalleryScreen: React.FC<{t: number}> = ({t}) => {
  const picks = [4, 0, 7];
  return (
    <g>
      <rect width={SW} height={SH} fill="#f8f6f1" />
      <T x={36} y={130} s={34} w={800}>Картинки для друзей</T>
      <T x={36} y={172} s={24} w={600} c="#8a93a8">выбрано: {picks.filter((_, k) => t >= C.chose + 0.15 + k * 0.42).length} из 3</T>
      {Array.from({length: 9}).map((_, i) => {
        const x = 24 + (i % 3) * 176, y = 210 + Math.floor(i / 3) * 236;
        const pk = picks.indexOf(i);
        const on = pk >= 0 && t >= C.chose + 0.15 + pk * 0.42;
        return (
          <g key={i} transform={`translate(${x} ${y})`}>
            <Artwork k={i} w={160} h={220} />
            {on && <g><rect width={160} height={220} rx={10} fill="none" stroke={PAL.green} strokeWidth={8} /><circle cx={130} cy={30} r={24} fill={PAL.green} /><T x={130} y={41} s={30} w={800} c="#fff" a="middle">{pk + 1}</T></g>}
          </g>
        );
      })}
    </g>
  );
};

/** 10. Чат с кафе: черновик → «Удалить?» → отправлено → ответы кафе */
const DRAFT = ['Здравствуйте! Хочу помочь', 'с фотографиями для вашей', 'страницы. Вот три мои работы.'];
export const CafeChat: React.FC<{t: number}> = ({t}) => {
  const typed = clamp((t - C.wrote2 - 0.15) / 1.9);
  const reread = t >= C.reread && t < C.delete;
  const ask = win(t, C.delete + 0.1, C.delete + 0.4, C.send - 0.1, C.send + 0.25);
  const sent = sm(t, C.send + 0.7, C.send + 1.05);
  const r1 = t >= C.hello - 0.4 ? revealByWords(t, CI.hello, CI.hello + 11) : 0;
  const r2 = t >= C.need - 0.3 ? revealByWords(t, CI.need, CI.need + 5) : 0;
  const typing2 = t >= C.another && t < C.need - 0.3;
  const chip = sm(t, C.morning - 0.1, C.morning + 0.3);
  const scrollUp = sm(t, C.hello - 0.5, C.hello) * 210 + sm(t, C.another, C.another + 0.4) * 280;
  const msg1 = 'Здравствуйте. Ваши работы понравились. Можете показать, как бы вы оформили нашу страницу?';
  const lines1 = ['Здравствуйте.', 'Ваши работы', 'понравились.', 'Можете показать,', 'как бы вы оформили', 'нашу страницу?'];
  const shown1 = Math.round(msg1.length * r1);
  let acc = 0;
  return (
    <g>
      <rect width={SW} height={SH} fill="#eef1f5" />
      <g transform={`translate(0 ${-scrollUp})`}>
        {/* отправленное сообщение */}
        <g transform={`translate(0 ${(1 - sent) * 380})`} opacity={sent > 0 ? 1 : 0}>
          <Card x={60} y={260} w={SW - 84} h={360} c="#d9f3e4" r={28}>
            {[0, 1, 2].map((k) => <g key={k} transform={`translate(${84 + k * 150} 284)`}><Artwork k={[4, 0, 7][k]} w={136} h={150} /></g>)}
            {DRAFT.map((l, i) => <T key={i} x={84} y={490 + i * 38} s={27} w={600}>{l}</T>)}
            <T x={SW - 40} y={600} s={22} w={600} c="#4f9a72" a="end">{t > C.send + 1.3 ? 'доставлено ✓' : ''}</T>
          </Card>
        </g>
        {/* ответы кафе */}
        {r1 > 0 && (
          <Card x={20} y={660} w={SW - 40} h={340} c="#fff" r={28}>
            {lines1.map((l, i) => {
              const start = acc; acc += l.length + 1;
              const vis = clamp((shown1 - start) / l.length);
              return <T key={i} x={44} y={716 + i * 52} s={38} w={i === 1 || i === 2 ? 800 : 700}>{l.slice(0, Math.round(l.length * vis))}</T>;
            })}
          </Card>
        )}
        {typing2 && <Card x={20} y={1020} w={130} h={70} c="#fff" r={28}>{[0, 1, 2].map((i) => <circle key={i} cx={54 + i * 30} cy={1055} r={8} fill="#9aa6bf" opacity={0.4 + 0.6 * Math.max(0, Math.sin(t * 8 - i))} />)}</Card>}
        {r2 > 0 && (
          <Card x={20} y={1020} w={SW - 40} h={150} c="#fff" r={28}>
            <T x={44} y={1080} s={40} w={700}>{'Нам нужен пример'.slice(0, Math.round(16 * Math.min(1, r2 * 1.6)))}</T>
            <T x={44} y={1134} s={40} w={800}>{'к завтрашнему утру.'.slice(0, Math.round(19 * clamp(r2 * 1.6 - 0.6)))}</T>
          </Card>
        )}
      </g>
      {/* шапка чата */}
      <rect width={SW} height={180} fill="#fff" />
      <g transform="translate(80 124)"><Icon kind="cup" size={66} /></g>
      <T x={130} y={136} s={30} w={800}>Кафе</T>
      {chip > 0 && (
        <g opacity={chip}>
          <rect x={40} y={940} width={SW - 80} height={92} rx={46} fill="#ffe7d3" stroke="#f0a36b" strokeWidth={3} />
          <T x={SW / 2} y={1000} s={40} w={800} c="#c0571f" a="middle">К ЗАВТРАШНЕМУ УТРУ</T>
        </g>
      )}
      {/* поле ввода с черновиком */}
      {sent < 0.05 && (
        <g>
          <rect x={0} y={SH - 420} width={SW} height={420} fill="#fff" />
          <g>
            {[0, 1, 2].map((k) => <g key={k} transform={`translate(${30 + k * 120} ${SH - 400})`}><Artwork k={[4, 0, 7][k]} w={104} h={110} /></g>)}
          </g>
          <rect x={24} y={SH - 270} width={SW - 130} height={170} rx={28} fill={ask > 0.3 ? '#cfe2ff' : '#f2f2ef'} />
          {DRAFT.map((l, i) => {
            const a = clamp(typed * 3 - i);
            return <T key={i} x={44} y={SH - 220 + i * 44} s={28} w={600}>{l.slice(0, Math.round(l.length * a))}</T>;
          })}
          {reread && <rect x={40} y={SH - 246 + ((Math.floor((t - C.reread) * 3) % 3) * 44)} width={SW - 170} height={34} rx={8} fill={PAL.green} opacity={0.18} />}
          <circle cx={SW - 58} cy={SH - 185} r={40} fill={PAL.green} />
          <path d={`M${SW - 76} ${SH - 200} L${SW - 36} ${SH - 185} L${SW - 76} ${SH - 170} L${SW - 70} ${SH - 185}Z`} fill="#fff" />
        </g>
      )}
      {ask > 0 && (
        <g opacity={ask}>
          <rect width={SW} height={SH} fill="#000" opacity={0.25} />
          <Card x={50} y={380} w={SW - 100} h={300} c="#fff" r={30}>
            <T x={SW / 2} y={470} s={34} w={800} a="middle">Удалить черновик?</T>
            <rect x={80} y={540} width={180} height={80} rx={40} fill="#ffe1dc" />
            <T x={170} y={592} s={30} w={800} c="#d24a3a" a="middle">Удалить</T>
            <rect x={SW - 260} y={540} width={180} height={80} rx={40} fill="#eef1f5" />
            <T x={SW - 170} y={592} s={30} w={800} c="#5b6785" a="middle">Отмена</T>
          </Card>
        </g>
      )}
    </g>
  );
};

/** точки, куда «нажимает» большой палец в чате */
export const chatThumb = (t: number): {pos: [number, number] | null; press: number} => {
  if (t >= C.delete && t < C.send + 0.25) {
    const toCancel = sm(t, C.nothingOffer + 0.8, C.send);
    return {pos: [toCancel > 0.5 ? SW - 170 : 170, 600], press: win(t, C.send - 0.15, C.send - 0.05, C.send + 0.05, C.send + 0.2)};
  }
  if (t >= C.send + 0.25 && t < C.send + 1.2) return {pos: [SW - 58, SH - 185], press: win(t, C.send + 0.55, C.send + 0.65, C.send + 0.75, C.send + 0.9)};
  if (t >= C.wrote2 && t < C.reread) return {pos: [150 + 260 * ((Math.floor(t * 9) % 5) / 4), SH - 160], press: 0.5 + 0.5 * Math.sin(t * 30)};
  return null as any;
};

export const _w = win;
