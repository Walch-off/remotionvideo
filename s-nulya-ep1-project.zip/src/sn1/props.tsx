import React from 'react';
import {SKIN} from '../common';

export const PAL = {
  cream: '#f7efe0', wall: '#f2e6cf', wallShade: '#e6d6b8', blue: '#4a78c2', blueDeep: '#2d4f8e', blueSoft: '#9cc3f0',
  green: '#3fb77a', greenSoft: '#bfe8cf', greenDeep: '#23875a', wood: '#c99b6b', woodDark: '#a57650', ink: '#1f2b45', white: '#fffbf3',
};

/** Сжатый кулак — центр в (0,0) (повторяет кисть персонажа) */
export const Fist: React.FC<{thumbSide?: 1 | -1}> = ({thumbSide = 1}) => (
  <g>
    <rect x={-27} y={-28} width={54} height={54} rx={20} fill={SKIN} stroke="#d49a6e" strokeWidth={2.5} />
    {[-14, -1, 12].map((x, i) => <path key={i} d={`M${x} -20 v34`} stroke="#d9a67a" strokeWidth={2.4} strokeLinecap="round" opacity={0.85} />)}
    <path d={`M${thumbSide * 20} -18 q${thumbSide * 14} 10 ${thumbSide * 6} 30`} stroke="#d49a6e" strokeWidth={3} fill={SKIN} />
  </g>
);

/** Смартфон в кулаке: экран к зрителю, вертикально в мире. lit — экран светится. */
export const PhoneInFist: React.FC<{worldRot: number; lit?: number}> = ({worldRot, lit = 1}) => (
  <g>
    <g transform={`rotate(${-worldRot})`}>
      <rect x={-40} y={-180} width={80} height={156} rx={14} fill="#20283c" stroke="#5a6688" strokeWidth={3} />
      <rect x={-34} y={-172} width={68} height={140} rx={9} fill={lit > 0.5 ? '#eaf3ff' : '#1a2132'} />
      {lit > 0.5 && <rect x={-26} y={-150} width={52} height={22} rx={6} fill={PAL.green} opacity={0.8} />}
      {lit > 0.5 && <rect x={-26} y={-120} width={40} height={8} rx={4} fill="#9fb2d6" />}
    </g>
    <Fist thumbSide={-1} />
  </g>
);

/** Телефон у уха: корпус за кистью, видна верхняя часть */
export const PhoneAtEar: React.FC<{worldRot: number}> = ({worldRot}) => (
  <g>
    <g transform={`rotate(${-worldRot}) translate(-8 -6) rotate(-12)`}>
      <rect x={-22} y={-95} width={44} height={150} rx={10} fill="#20283c" stroke="#5a6688" strokeWidth={3} />
    </g>
    <Fist thumbSide={-1} />
  </g>
);

/** Телефон лежит на столе (вид спереди-сверху): тонкая плашка, экран вверх */
export const PhoneOnDesk: React.FC<{lit?: number; t: number}> = ({lit = 0, t}) => (
  <g>
    <ellipse cx={0} cy={6} rx={70} ry={10} fill="#000" opacity={0.15} />
    <path d="M-62 0 L-48 -18 L48 -18 L62 0Z" fill="#20283c" />
    <path d="M-56 -2 L-45 -15 L45 -15 L56 -2Z" fill={lit > 0 ? '#eaf3ff' : '#2a3350'} />
    <rect x={-62} y={0} width={124} height={7} rx={3} fill="#3a4466" />
    {lit > 0 && <ellipse cx={0} cy={-40} rx={120} ry={70} fill="#cfe2ff" opacity={0.35 * lit * (0.75 + 0.25 * Math.sin(t * 12))} />}
  </g>
);

/** Корзинка из магазина в кулаке (ручка в кулаке, корзина висит вниз) */
export const BasketInFist: React.FC<{worldRot: number}> = ({worldRot}) => (
  <g>
    <g transform={`rotate(${-worldRot})`}>
      <path d="M-50 10 Q0 -40 50 10" stroke="#2f7d55" strokeWidth={8} fill="none" />
      <path d="M-80 10 L80 10 L66 120 L-66 120Z" fill={PAL.green} stroke={PAL.greenDeep} strokeWidth={4} />
      {[0, 1, 2].map((k) => <path key={k} d={`M-74 ${36 + k * 28} H74`} stroke={PAL.greenDeep} strokeWidth={3} opacity={0.6} />)}
      {/* простые продукты: батон, макароны, лоток яиц */}
      <ellipse cx={-30} cy={0} rx={44} ry={20} fill="#e2b36d" stroke="#b07f3e" strokeWidth={3} />
      <rect x={10} y={-26} width={40} height={40} rx={6} fill="#f6d65a" stroke="#c9a632" strokeWidth={3} />
    </g>
    <Fist />
  </g>
);

/** Бумажный пакет с продуктами в кулаке */
export const BagInFist: React.FC<{worldRot: number}> = ({worldRot}) => (
  <g>
    <g transform={`rotate(${-worldRot})`}>
      <path d="M-30 6 Q0 -30 30 6" stroke="#b5885a" strokeWidth={8} fill="none" />
      <path d="M-70 6 L70 6 L78 190 L-78 190Z" fill="#d9b48a" stroke="#a9835a" strokeWidth={4} />
      <ellipse cx={-30} cy={2} rx={36} ry={18} fill="#e2b36d" stroke="#b07f3e" strokeWidth={3} />
      <rect x={10} y={-30} width={34} height={44} rx={5} fill="#fdfbf3" stroke="#c6c0b0" strokeWidth={3} />
      <path d="M-40 110 h80" stroke="#a9835a" strokeWidth={3} opacity={0.6} />
    </g>
    <Fist />
  </g>
);

/** Иконки для UI (рисованные, без эмодзи) */
export const Icon: React.FC<{kind: 'food' | 'clothes' | 'sub' | 'salary' | 'home' | 'cup' | 'bell' | 'job' | 'calendar'; size?: number}> = ({kind, size = 64}) => {
  const s = size / 64;
  const bg = {food: '#ff8a4c', clothes: '#9b6cf0', sub: PAL.green, salary: PAL.green, home: PAL.blue, cup: '#c98a52', bell: '#f2b632', job: '#f2b632', calendar: PAL.green}[kind];
  return (
    <g transform={`scale(${s})`}>
      <rect x={-32} y={-32} width={64} height={64} rx={18} fill={bg} />
      {kind === 'food' && <g fill="#fff"><path d="M-18 -4 Q0 -26 18 -4Z" /><rect x={-20} y={-2} width={40} height={7} rx={3} /><rect x={-18} y={8} width={36} height={9} rx={4} /></g>}
      {kind === 'clothes' && <path d="M-20 -14 L-8 -20 Q0 -12 8 -20 L20 -14 L16 -4 L10 -6 L10 20 L-10 20 L-10 -6 L-16 -4Z" fill="#fff" />}
      {kind === 'sub' && <path d="M-8 -14 L14 0 L-8 14Z" fill="#fff" />}
      {kind === 'salary' && <g fill="#fff"><rect x={-20} y={-12} width={40} height={26} rx={5} /><circle cx={0} cy={1} r={7} fill={bg} /></g>}
      {kind === 'home' && <path d="M-18 2 L0 -16 L18 2 L18 18 L-18 18Z" fill="#fff" />}
      {kind === 'cup' && <g fill="#fff"><path d="M-16 -8 H12 V8 Q12 18 -2 18 Q-16 18 -16 8Z" /><path d="M12 -4 q10 0 10 7 q0 7 -10 7" stroke="#fff" strokeWidth={4} fill="none" /></g>}
      {kind === 'bell' && <path d="M0 -18 Q14 -16 14 2 L18 10 L-18 10 L-14 2 Q-14 -16 0 -18Z M-5 13 Q0 19 5 13Z" fill="#fff" />}
      {kind === 'job' && <g fill="#fff"><rect x={-18} y={-8} width={36} height={26} rx={4} /><rect x={-7} y={-16} width={14} height={10} rx={3} fill="none" stroke="#fff" strokeWidth={4} /></g>}
      {kind === 'calendar' && <g><rect x={-18} y={-14} width={36} height={32} rx={5} fill="#fff" /><rect x={-18} y={-14} width={36} height={9} rx={4} fill="#1d7a4f" /></g>}
    </g>
  );
};

/** Миниатюры старых работ героя (открытки, афиши для друзей) */
export const Artwork: React.FC<{k: number; w: number; h: number}> = ({k, w, h}) => {
  const bg = ['#ffd27a', '#9fd6ff', '#ffb3c7', '#c6f0b8', '#d9c8ff', '#ffe0b0', '#b8e6e0', '#ffcf9e', '#cfe0ff'][k % 9];
  const fg = ['#e0583a', '#2d63c8', '#c2347a', '#2f9a5a', '#6a48c9', '#d4802a', '#2a8f86', '#c95f2a', '#3a5fc8'][k % 9];
  return (
    <g>
      <rect width={w} height={h} rx={10} fill={bg} />
      {k % 3 === 0 && <g><circle cx={w * 0.5} cy={h * 0.42} r={w * 0.22} fill={fg} /><rect x={w * 0.2} y={h * 0.75} width={w * 0.6} height={h * 0.08} rx={4} fill={fg} /></g>}
      {k % 3 === 1 && <g><path d={`M${w * 0.15} ${h * 0.8} L${w * 0.45} ${h * 0.3} L${w * 0.65} ${h * 0.6} L${w * 0.75} ${h * 0.45} L${w * 0.9} ${h * 0.8}Z`} fill={fg} /><circle cx={w * 0.78} cy={h * 0.25} r={w * 0.08} fill="#fff" /></g>}
      {k % 3 === 2 && <g>{[0, 1, 2].map((i) => <rect key={i} x={w * (0.15 + i * 0.25)} y={h * (0.6 - i * 0.12)} width={w * 0.18} height={h * (0.25 + i * 0.12)} rx={4} fill={fg} opacity={0.6 + i * 0.2} />)}</g>}
    </g>
  );
};
