/**
 * ЛИСТ ПРЕЕМСТВЕННОСТИ серии 1 — где герой и предметы в каждый момент. Все планы берут состояние отсюда.
 *
 * Герой:   стоит в комнате у окна (0–24) → кухня у холодильника (24–37) → сидит за столом (37–114) →
 *          прихожая/магазин/прихожая (117–121) → снова за столом (121–конец).
 * Телефон: в ПРАВОЙ руке; «убрал телефон» — кладёт на стол справа; «позвонил» — берёт и подносит к уху;
 *          после звонка снова в руке; после отправки сообщения — на столе; уходя в магазин, оставляет на столе;
 *          вечером берёт со стола; «посмотрел на часы» — кладёт обратно и дальше не трогает.
 * Ноутбук: старый, закрытый, на полке над столом → «на старый ноутбук» — снят с полки → на столе слева от героя, открыт.
 * Холодильник: закрыт → открыт (24,4) → закрыт («потом уже наступило»).
 * Свет:    день → вечер (тёплое окно) → ночь (настольная лампа).
 */
import {C, sm, win, path, num} from './story';
import {reach, Face} from '../components/Hero';

export const ROOM = {floor: 1580, deskTop: 1330, standX: 330, sitX: 840};
export const PHONE_DESK = {x: 1000, y: 1326};
export const LAPTOP_DESK = {x: 610, y: 1330};

const REST_L: [number, number] = [404, 664];
const REST_R: [number, number] = [606, 664];
const HOLD_R: [number, number] = [562, 505];
const EAR_R: [number, number] = [612, 262];
const DESK_L: [number, number] = [430, 520];
const DESK_R: [number, number] = [585, 520];
/** точка телефона на столе в координатах сидящего героя (якорь-пояс (505,575) в мире (sitX, deskTop+55)) */
const PH_DESK_H: [number, number] = [PHONE_DESK.x - ROOM.sitX + 505, PHONE_DESK.y - (ROOM.deskTop + 55) + 575 - 4];

export type Pose = {armL: number; elbowL: number; armR: number; elbowR: number; face: Face; face2?: Face; faceMix: number; look: [number, number]; turn: number; tilt: number; bob: number};
export type PhoneWhere = 'hand' | 'ear' | 'desk';

/** где телефон */
export const phoneWhere = (t: number): PhoneWhere => {
  if (t >= C.putAway + 0.55 && t < C.call + 0.35) return 'desk';
  if (t >= C.call + 0.35 && t < C.onlyWeek + 0.9) return 'ear';
  if (t >= C.sendWord + 1.0 && t < C.evening + 1.15) return 'desk';
  if (t >= C.clock + 0.9) return 'desk';
  return 'hand';
};
export const phoneLit = (t: number) => (t >= C.evening + 0.35 && t < C.evening + 1.2 ? 1 : 0);

const mk = (side: 'L' | 'R', p: [number, number]) => reach(side, p[0], p[1], 1);

/** стоя (комната, кухня): правая рука держит телефон у груди */
export const standPose = (t: number, where: 'room' | 'kitchen'): Pose => {
  const R = mk('R', HOLD_R), L = mk('L', REST_L);
  let face: Face = 'worried', face2: Face | undefined, faceMix = 0, look: [number, number] = [0.2, 0.9], turn = 0.05, tilt = 0;
  if (where === 'room') {
    if (t < C.three) { face = 'surprised'; face2 = 'worried'; faceMix = sm(t, C.balance, C.three); }
    if (t >= C.three && t < C.looked) { face = 'worried'; look = [0.2, 0.9]; }
    if (t >= C.looked && t < C.salary) { face = 'sad'; look = [0.15, 0.85]; }
    if (t >= C.salary) { face = 'sad'; look = [-0.5, -0.3]; turn = -0.2; }
  } else {
    face = t < C.eggs ? 'worried' : 'sad'; look = [-0.9, 0.1]; turn = -0.55;
    if (t >= C.first && t < C.because) { face = 'sad'; look = [-0.4, 0.6]; turn = -0.2; tilt = -3; }
    if (t >= C.because) { face = 'frustrated'; look = [-0.8, 0.2]; turn = -0.45; }
  }
  return {armL: L.arm, elbowL: L.elbow, armR: R.arm, elbowR: R.elbow, face, face2, faceMix, look, turn, tilt, bob: 0};
};

/** сидя за столом */
export const deskPose = (t: number): Pose & {phone: PhoneWhere; sit: number} => {
  const phone = phoneWhere(t);
  const R: [number, number, number][] = [
    [0, ...HOLD_R], [C.putAway + 0.1, ...HOLD_R], [C.putAway + 0.55, ...PH_DESK_H], [C.putAway + 0.9, ...DESK_R],
    [C.call - 0.05, ...DESK_R], [C.call + 0.35, ...PH_DESK_H], [C.call + 0.95, ...EAR_R], [C.onlyWeek + 0.5, ...EAR_R], [C.onlyWeek + 1.1, ...HOLD_R],
    [C.sendWord + 0.6, ...HOLD_R], [C.sendWord + 1.0, ...PH_DESK_H], [C.sendWord + 1.4, ...DESK_R],
    [C.evening + 0.7, ...DESK_R], [C.evening + 1.15, ...PH_DESK_H], [C.evening + 1.7, ...HOLD_R],
    [C.clock + 0.4, ...HOLD_R], [C.clock + 0.9, ...PH_DESK_H], [C.clock + 1.3, ...DESK_R], [C.press - 0.2, ...DESK_R],
  ];
  const [rx, ry] = path(t, R);
  const aR = reach('R', rx, ry, 1);
  const lp = path(t, [[0, ...DESK_L], [C.press - 0.3, ...DESK_L], [C.press + 0.2, 300, 505], [C.off + 0.4, 300, 505], [C.off + 1.0, ...DESK_L]]);
  const aL = reach('L', lp[0], lp[1], 1);
  let face: Face = 'worried', face2: Face | undefined, faceMix = 0, look: [number, number] = [0.25, 0.85], turn = 0.05, tilt = 0;
  const seg = (a: number, b: number) => t >= a && t < b;
  if (seg(C.sum, C.stare)) { face = 'surprised'; face2 = 'sad'; faceMix = sm(t, C.bigger, C.stare); }
  if (seg(C.stare, C.cancel)) { face = 'blank'; look = [0.2, 0.75]; }
  if (seg(C.cancel, C.putAway)) { face = 'focused'; }
  if (seg(C.putAway, C.call)) { face = 'worried'; look = [0.3, 0.4]; tilt = -3; }
  if (seg(C.call, C.agreed)) { face = 'worried'; look = [-0.3, 0.3]; turn = -0.15; if (t >= C.voice) { face2 = 'surprised'; faceMix = talkish(t, C.voice, C.later + 0.6); } }
  if (seg(C.agreed, C.seven)) { face = 'tired'; look = [-0.2, 0.2]; turn = -0.1; }
  if (seg(C.seven, C.search)) { face = 'focused'; look = [0.2, 0.8]; }
  if (seg(C.search, C.until)) { face = 'focused'; }
  if (seg(C.until, C.risk)) { face = 'worried'; }
  if (seg(C.risk, C.ad2)) { face = 'sad'; look = [-0.4, 0.2]; turn = -0.2; }
  if (seg(C.ad2, C.reread)) { face = 'focused'; }
  if (seg(C.reread, C.send)) { face = 'worried'; look = [0.25 + 0.45 * Math.sin(t * 5), 0.8]; }
  if (seg(C.send, C.hour)) { face = 'worried'; }
  if (seg(C.hour, C.evening)) { face = 'tired'; look = [0.6, 0.5]; turn = 0.2; }
  if (seg(C.evening, C.smiled)) { face = 'surprised'; look = [0.25, 0.85]; }
  if (seg(C.smiled, C.another)) { face = 'smile'; look = [0.15, 0.6]; }
  if (seg(C.another, C.clock)) { face = 'surprised'; face2 = 'worried'; faceMix = sm(t, C.need, C.morning); }
  if (seg(C.clock, C.thenLaptop)) { face = 'worried'; look = [-0.3, -1]; turn = -0.1; }
  if (seg(C.thenLaptop, C.press)) { face = 'worried'; look = [-0.9, 0.5]; turn = -0.4; }
  if (seg(C.press, C.off)) { face = 'focused'; look = [-0.8, 0.5]; turn = -0.4; }
  if (seg(C.off, C.q)) { face = 'frustrated'; look = [-0.7, 0.4]; turn = -0.35; }
  if (t >= C.q) { face = 'sad'; look = [0, 0.1]; turn = 0; }
  const sit = sm(t, C.sat - 0.1, C.sat + 0.55);
  const sigh = -6 * win(t, C.agreed + 0.6, C.agreed + 1.0, C.agreed + 1.4, C.agreed + 2.2);
  return {armL: aL.arm, elbowL: aL.elbow, armR: aR.arm, elbowR: aR.elbow, face, face2, faceMix, look, turn, tilt, bob: sigh, phone, sit};
};
const talkish = (t: number, a: number, b: number) => (t > a && t < b ? 0.3 * Math.abs(Math.sin((t - a) * 9)) : 0);

/** ноутбук: на полке → снят → на столе (закрыт → открыт) → включение → мигнул → погас */
export const laptopState = (t: number) => ({
  onShelf: t < C.laptop + 0.2,
  onDesk: t >= C.laptop + 0.9,
  lid: sm(t, C.laptop + 1.0, C.laptop + 1.6),
  led: t >= C.press + 0.55 && t < C.off ? 1 : 0,
  screen: t < C.press + 0.8 ? 0 : t < C.blink ? 0.25 * sm(t, C.press + 0.8, C.blink) : t < C.off ? (Math.sin(t * 38) > 0 ? 0.9 : 0.15) : 0,
});

export const fridgeOpen = (t: number) => num(t, [[C.fridge - 0.7, 0], [C.fridge - 0.15, 1], [C.arrived + 0.15, 1], [C.arrived + 0.75, 0]]);
