import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Hero, reach} from '../components/Hero';
import {SKIN, clamp} from '../common';
import {C, sm, win, dayPhase} from './story';
import {laptopState} from './state';
import {PAL} from './props';
import {WallClock, clockMinutes, Sky} from './Sets';
import {BankScreen, SW, SH} from './Phone';

const F = 'Manrope';

/** Кисть, обхватившая край телефона: ладонь за корпусом, большой палец на экране сбоку, рукав уходит вниз */
const GripHand: React.FC<{x: number; y: number; side: 1 | -1}> = ({x, y, side}) => (
  <g transform={`translate(${x} ${y}) scale(${side} 1)`}>
    <path d="M-30 120 L120 140 L240 700 L-120 700Z" fill="#5470a6" />
    <path d="M60 128 L120 140 L240 700 L150 700Z" fill="#3a5287" opacity={0.45} />
    <rect x={-60} y={100} width={190} height={70} rx={26} fill="#445f95" transform="rotate(6)" />
    <path d="M-70 -30 Q-80 90 -10 120 L110 120 Q130 40 100 -40Z" fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
    {[0, 1, 2].map((i) => <rect key={i} x={70} y={-120 + i * 56} width={64} height={48} rx={22} fill={SKIN} stroke="#d49a6e" strokeWidth={3} />)}
    <g transform="translate(-50 -10) rotate(20)"><rect x={-26} y={-110} width={52} height={130} rx={26} fill={SKIN} stroke="#d49a6e" strokeWidth={4} /><ellipse cx={0} cy={-90} rx={16} ry={20} fill="#f9dcbd" /></g>
  </g>
);

/** Крючок: лицо героя сверху крупно, телефон с балансом «300 ₽» в двух руках ближе к камере */
export const HookShot: React.FC<{t: number}> = ({t}) => {
  const aL = reach('L', 470, 720, 1), aR = reach('R', 540, 720, 1);
  const PS = 0.62, pw = SW * PS, ph = SH * PS, px = 540 - pw / 2, py = 770;
  const push = 1 + 0.03 * sm(t, 0, C.three);
  return (
    <g transform={`translate(540 960) scale(${push}) translate(-540 -960)`}>
      <rect width={1080} height={1920} fill="#f3e9d6" />
      <g filter="url(#blur18)">
        <rect x={-60} y={140} width={420} height={640} rx={20} fill="#bfe3ff" />
        <rect x={-90} y={120} width={70} height={700} fill={PAL.green} opacity={0.8} />
        <circle cx={930} cy={360} r={150} fill={PAL.greenSoft} />
        <rect x={-100} y={1450} width={1300} height={600} fill="#e7d8bc" />
      </g>
      <Hero id="hook" x={540} y={420} scale={1.6} anchor={[505, 200]} legs={false} stain={false}
        armL={aL.arm} elbowL={aL.elbow} armR={aR.arm} elbowR={aR.elbow}
        face={t < C.balance ? 'worried' : 'surprised'} face2="sad" faceMix={sm(t, C.three + 0.2, C.three + 1.0)} look={[0, 0.95]} tilt={-3} blinkSeed={7} />
      <g transform={`translate(${px} ${py})`}>
        <rect x={-20} y={-20} width={pw + 40} height={ph + 40} rx={58} fill="#1d2232" />
        <rect x={-14} y={-14} width={pw + 28} height={ph + 28} rx={52} fill="none" stroke="#59627d" strokeWidth={3} />
        <clipPath id="hookScr"><rect width={pw} height={ph} rx={40} /></clipPath>
        <g clipPath="url(#hookScr)"><g transform={`scale(${PS})`}><BankScreen t={t} /></g></g>
        <GripHand x={-40} y={ph - 140} side={1} />
        <GripHand x={pw + 40} y={ph - 140} side={-1} />
      </g>
    </g>
  );
};

/** Полка со старым ноутбуком крупно: руки снимают его */
export const ShelfCU: React.FC<{t: number}> = ({t}) => {
  const grab = sm(t, C.laptop - 0.2, C.laptop + 0.3);
  const lift = sm(t, C.laptop + 0.45, C.laptop + 1.3);
  const night = Math.max(0, dayPhase(t) - 1);
  const ly = 1000 + 700 * lift;
  return (
    <g>
      <rect width={1080} height={1920} fill="#ecdfc6" />
      <rect x={0} y={1040} width={1080} height={60} fill="#a57650" />
      {[[60, '#e35d5b', 360], [150, '#4a78c2', 420], [250, '#f2b632', 330]].map(([x, c, h], i) => <rect key={i} x={x as number} y={1040 - (h as number)} width={80} height={h as number} rx={8} fill={c as string} />)}
      <g transform={`translate(640 ${ly}) scale(2.6)`}>
        <rect x={-115} y={-24} width={230} height={24} rx={6} fill="#8d95a6" />
        <rect x={-115} y={-24} width={230} height={8} rx={4} fill="#a9b0bf" />
        <rect x={40} y={-21} width={34} height={14} rx={3} fill="#ffe08a" />
        {[-90, -60, -20, 10, 60, 95].map((x, i) => <circle key={i} cx={x} cy={-25} r={2 + (i % 3)} fill="#d8d2c4" />)}
      </g>
      {/* пыль слетает при подъёме */}
      {lift > 0 && lift < 1 && Array.from({length: 14}).map((_, i) => <circle key={i} cx={420 + i * 34} cy={ly - 80 - lift * (60 + (i % 4) * 30)} r={4} fill="#efe6d4" opacity={0.8 * (1 - lift)} />)}
      {/* две руки снизу кадра */}
      {[-1, 1].map((s) => (
        <g key={s} transform={`translate(${640 + s * 330 * (1 - 0.1 * grab)} ${ly + 30 + 600 * (1 - grab)})`}>
          <path d={`M${-70} 40 L${70} 40 L${110} 900 L${-110} 900Z`} fill="#5470a6" />
          <rect x={-80} y={30} width={160} height={70} rx={26} fill="#445f95" />
          <path d={`M${-60} 30 Q${-70 * s - 20} -60 ${-s * 40} -80 L${s * 70} -60 Q${s * 80} 0 60 30Z`} fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
        </g>
      ))}
      <rect width={1080} height={1920} fill="#1b2350" opacity={0.4 * night} />
    </g>
  );
};

/** Кнопка питания ноутбука: палец нажимает, загорается индикатор */
export const PowerCU: React.FC<{t: number}> = ({t}) => {
  const press = win(t, C.press + 0.4, C.press + 0.55, C.press + 0.7, C.press + 0.9);
  const reachIn = sm(t, C.press - 0.1, C.press + 0.45);
  const ls = laptopState(t);
  return (
    <g>
      <rect width={1080} height={1920} fill="#4a3f52" />
      <rect x={-40} y={420} width={1160} height={1200} rx={40} fill="#9aa2b3" />
      <rect x={-40} y={420} width={1160} height={30} fill="#b7becd" />
      {Array.from({length: 4}).map((_, r) => Array.from({length: 9}).map((_, c) => (
        <rect key={`${r}-${c}`} x={10 + c * 118} y={720 + r * 118} width={100} height={100} rx={14} fill="#2e3346" />
      )))}
      <circle cx={900} cy={560} r={58} fill="#2e3346" />
      <circle cx={900} cy={560} r={30} fill="none" stroke={ls.led ? '#5fe39a' : '#8b93a7'} strokeWidth={7} />
      <rect x={895} y={520} width={10} height={36} rx={5} fill={ls.led ? '#5fe39a' : '#8b93a7'} />
      {ls.led > 0 && <circle cx={900} cy={560} r={90} fill="#5fe39a" opacity={0.25} filter="url(#blur18)" />}
      {/* палец-указатель: рука снизу слева */}
      <g transform={`translate(${900 - 420 * (1 - reachIn)} ${560 + 6 + 900 * (1 - reachIn) + 14 * press})`}>
        <rect x={-30} y={-10} width={60} height={200} rx={30} fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
        <path d="M-90 150 Q-120 330 -40 420 L120 420 Q170 300 120 160Z" fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
        <path d="M-120 400 L160 400 L260 1400 L-220 1400Z" fill="#5470a6" />
        <rect x={-130} y={390} width={300} height={80} rx={30} fill="#445f95" />
      </g>
      <rect width={1080} height={1920} fill="#1b2350" opacity={0.3} />
      <ellipse cx={1000} cy={200} rx={620} ry={520} fill="url(#lampPool)" opacity={0.9} style={{mixBlendMode: "screen"}} />
    </g>
  );
};

/** Экран ноутбука: мигнул… и погас */
export const ScreenCU: React.FC<{t: number}> = ({t}) => {
  const ls = laptopState(t);
  const frame = useCurrentFrame();
  return (
    <g>
      <rect width={1080} height={1920} fill="#4a3f52" />
      <rect x={0} y={1100} width={1080} height={820} fill="#8a6648" />
      <ellipse cx={980} cy={700} rx={640} ry={620} fill="url(#lampPool)" opacity={0.9} style={{mixBlendMode: "screen"}} />
      <rect x={60} y={360} width={960} height={680} rx={36} fill="#7d8597" />
      <rect x={96} y={396} width={888} height={608} rx={14} fill="#0b0e16" />
      {ls.screen > 0.05 && (
        <g opacity={ls.screen}>
          <rect x={96} y={396} width={888} height={608} rx={14} fill="#dfe9ff" />
          {Array.from({length: 7}).map((_, i) => <rect key={i} x={96} y={396 + ((frame * 37 + i * 97) % 608)} width={888} height={6} fill="#a9b8dc" opacity={0.6} />)}
          <rect x={460} y={640} width={160} height={120} rx={20} fill="#b9c4dc" />
        </g>
      )}
      <rect x={20} y={1040} width={1040} height={60} rx={20} fill="#9aa2b3" />
      <circle cx={540} cy={1072} r={8} fill={ls.led ? '#5fe39a' : '#4a5263'} />
      <rect x={96} y={396} width={888} height={608} rx={14} fill="url(#screenSheen)" opacity={0.4} />
    </g>
  );
};

/** Часы на стене ночью + «ПОЧТИ 23:00» */
export const ClockCU: React.FC<{t: number}> = ({t}) => {
  const lab = sm(t, C.almost - 0.1, C.almost + 0.3);
  return (
    <g>
      <rect width={1080} height={1920} fill="#cbbfa8" />
      <rect x={-60} y={1250} width={560} height={720} rx={14} fill="#fffaf0" />
      <Sky t={t} x={-40} y={1270} w={520} h={700} />
      <WallClock x={560} y={760} r={300} minutes={clockMinutes(t)} />
      <rect width={1080} height={1920} fill="#1b2350" opacity={0.38} style={{mixBlendMode: 'multiply'}} />
      <ellipse cx={1000} cy={1300} rx={520} ry={500} fill="url(#lampPool)" opacity={0.7} style={{mixBlendMode: 'screen'}} />
      <g opacity={lab} transform={`translate(540 ${1250 + 20 * (1 - lab)})`}>
        <rect x={-260} y={-62} width={520} height={124} rx={62} fill="#fffaf0" />
        <text x={0} y={22} textAnchor="middle" fontFamily={F} fontWeight={800} fontSize={64} fill="#c0571f">ПОЧТИ 23:00</text>
      </g>
    </g>
  );
};

/** Телефон молчит на столе (после магазина) */
export const PhoneSilentCU: React.FC<{t: number}> = ({t}) => (
  <g>
    <rect width={1080} height={1920} fill="#ecdfc6" />
    <rect x={0} y={900} width={1080} height={1020} fill="url(#deskG)" />
    <g filter="url(#blur18)"><rect x={-100} y={200} width={500} height={600} fill="#bfe3ff" opacity={0.7} /><circle cx={880} cy={500} r={150} fill={PAL.greenSoft} /></g>
    <g transform="translate(540 1200) scale(3.2)">
      <ellipse cx={0} cy={10} rx={110} ry={16} fill="#000" opacity={0.15} />
      <path d="M-100 0 L-78 -60 L78 -60 L100 0Z" fill="#20283c" />
      <path d="M-92 -4 L-73 -54 L73 -54 L92 -4Z" fill="#2a3350" />
      <rect x={-100} y={0} width={200} height={8} rx={3} fill="#3a4466" />
    </g>
    <text x={540} y={1460} textAnchor="middle" fontFamily={F} fontWeight={700} fontSize={40} fill="#7a6a50" opacity={0.85 * sm(t, C.silent - 1.2, C.silent - 0.6)}>Новых сообщений нет</text>
  </g>
);

/** Финальная карточка */
export const ToBeContinued: React.FC<{t: number}> = ({t}) => {
  const a = sm(t, C.next + 0.3, C.next + 1.0);
  if (a <= 0) return null;
  return (
    <g opacity={a} transform={`translate(540 ${330 + 20 * (1 - a)})`}>
      <rect x={-400} y={-80} width={800} height={160} rx={80} fill="#fffaf0" opacity={0.94} />
      <text x={0} y={-6} textAnchor="middle" fontFamily={F} fontWeight={800} fontSize={54} fill={PAL.ink}>ПРОДОЛЖЕНИЕ</text>
      <text x={0} y={52} textAnchor="middle" fontFamily={F} fontWeight={800} fontSize={46} fill={PAL.greenDeep}>СЛЕДУЕТ</text>
    </g>
  );
};

export const _c = clamp;
