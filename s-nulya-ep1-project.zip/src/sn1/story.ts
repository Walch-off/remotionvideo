import words from '../data/words.json';
import cuesJson from '../data/cues.json';
import {clamp, ease, lerp} from '../common';

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export type Word = {text: string; s: number; e: number};
export const WORDS = words as Word[];
/** Все события — из реальных таймкодов слов озвучки после монтажа (scripts/build_audio.py). */
export const C = cuesJson.cues as unknown as Record<string, number>;
export const CI = cuesJson.idx as unknown as Record<string, number>;
export const DURATION = C.end;
export const TOTAL = Math.ceil(DURATION * FPS);

export const sm = (t: number, a: number, b: number) => ease(clamp((t - a) / (b - a)));
export const win = (t: number, a: number, b: number, c: number, d: number) => Math.min(sm(t, a, b), 1 - sm(t, c, d));

type KP = [number, number, number][];
/** плавный путь по ключевым точкам [t, x, y] */
export const path = (t: number, k: KP): [number, number] => {
  if (t <= k[0][0]) return [k[0][1], k[0][2]];
  for (let i = 1; i < k.length; i++) {
    if (t <= k[i][0]) {
      const u = sm(t, k[i - 1][0], k[i][0]);
      return [lerp(k[i - 1][1], k[i][1], u), lerp(k[i - 1][2], k[i][2], u)];
    }
  }
  const l = k[k.length - 1];
  return [l[1], l[2]];
};
export const num = (t: number, k: [number, number][]) => path(t, k.map(([a, v]) => [a, v, 0]))[0];

/** Время суток: 0 — день, 1 — вечер, 2 — ночь (плавно) */
export const dayPhase = (t: number) => sm(t, C.evening - 0.6, C.evening + 0.6) + sm(t, C.clock - 0.8, C.clock + 0.2);

/** доля показанного текста, синхронно со словами озвучки [from..to] */
export const revealByWords = (t: number, from: number, to: number) => {
  const a = WORDS[from].s, b = WORDS[to].e;
  return clamp((t - a + 0.15) / (b - a + 0.15));
};
