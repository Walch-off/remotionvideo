import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Hero} from '../components/Hero';
import {C, sm, dayPhase, num} from './story';
import {ROOM, PHONE_DESK, LAPTOP_DESK, standPose, deskPose, laptopState, fridgeOpen, phoneLit} from './state';
import {PAL, PhoneInFist, PhoneAtEar, PhoneOnDesk, BasketInFist, BagInFist} from './props';
import {reach} from '../components/Hero';
import {lerp} from '../common';

const HERO_STYLE = {stain: false, wet: 0, prints: {}} as const;

export const Defs: React.FC = () => (
  <defs>
    <linearGradient id="skyDay" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7cc2f2" /><stop offset="1" stopColor="#d8f0ff" /></linearGradient>
    <linearGradient id="skyEve" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7d7fd0" /><stop offset="0.55" stopColor="#f39a77" /><stop offset="1" stopColor="#ffd59a" /></linearGradient>
    <linearGradient id="skyNight" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#15204a" /><stop offset="1" stopColor="#2e3f78" /></linearGradient>
    <linearGradient id="wallG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f5ebd8" /><stop offset="1" stopColor="#ecdfc6" /></linearGradient>
    <linearGradient id="floorG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#c99b6b" /><stop offset="1" stopColor="#b08356" /></linearGradient>
    <linearGradient id="deskG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#dcb487" /><stop offset="1" stopColor="#c4986a" /></linearGradient>
    <radialGradient id="lampPool"><stop offset="0" stopColor="#ffd98f" stopOpacity={0.75} /><stop offset="1" stopColor="#ffd98f" stopOpacity={0} /></radialGradient>
    <radialGradient id="sunPool"><stop offset="0" stopColor="#fff2c8" stopOpacity={0.55} /><stop offset="1" stopColor="#fff2c8" stopOpacity={0} /></radialGradient>
    <radialGradient id="eveningPool"><stop offset="0" stopColor="#ffb37a" stopOpacity={0.55} /><stop offset="1" stopColor="#ffb37a" stopOpacity={0} /></radialGradient>
    <radialGradient id="fridgeLight"><stop offset="0" stopColor="#fffbe8" stopOpacity={0.85} /><stop offset="1" stopColor="#fffbe8" stopOpacity={0} /></radialGradient>
    <radialGradient id="softVig" cx="0.5" cy="0.5" r="0.78"><stop offset="0.65" stopColor="#000" stopOpacity={0} /><stop offset="1" stopColor="#2a1d10" stopOpacity={0.28} /></radialGradient>
    <filter id="blur6" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation={6} /></filter>
    <filter id="blur18" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation={18} /></filter>
    <filter id="blur3" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation={3} /></filter>
  </defs>
);

/** Небо за окном по времени суток; ночью — окна соседнего дома */
export const Sky: React.FC<{t: number; x: number; y: number; w: number; h: number}> = ({t, x, y, w, h}) => {
  const p = dayPhase(t);
  const frame = useCurrentFrame();
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} fill="url(#skyDay)" />
      <rect x={x} y={y} width={w} height={h} fill="url(#skyEve)" opacity={Math.min(1, p)} />
      <rect x={x} y={y} width={w} height={h} fill="url(#skyNight)" opacity={Math.max(0, p - 1)} />
      {/* облака днём, солнце вечером */}
      <g opacity={Math.max(0, 1 - p)}>
        {[[0.25, 0.25], [0.7, 0.4]].map(([cx, cy], i) => (
          <g key={i} transform={`translate(${x + w * cx + ((frame * 0.15 + i * 50) % 60)} ${y + h * cy})`}>
            <ellipse cx={0} cy={0} rx={60} ry={22} fill="#fff" opacity={0.9} /><ellipse cx={30} cy={-12} rx={36} ry={20} fill="#fff" opacity={0.9} />
          </g>
        ))}
      </g>
      <circle cx={x + w * 0.65} cy={y + h * 0.78} r={46} fill="#ffe2a6" opacity={Math.min(1, p) * Math.max(0, 2 - p - 0.6)} />
      {/* соседний дом */}
      <rect x={x + w * 0.05} y={y + h * 0.55} width={w * 0.5} height={h * 0.45} fill={p < 1 ? '#c9b8a4' : '#3b3f5e'} opacity={0.9} />
      <rect x={x + w * 0.62} y={y + h * 0.68} width={w * 0.38} height={h * 0.32} fill={p < 1 ? '#b8a892' : '#343857'} opacity={0.9} />
      {Array.from({length: 12}).map((_, i) => {
        const cx = x + w * 0.09 + (i % 4) * w * 0.11, cy = y + h * 0.6 + Math.floor(i / 4) * h * 0.12;
        const on = p > 1.3 ? ((i * 7) % 5 !== 0 ? 1 : 0) : p > 0.6 ? ((i * 3) % 4 === 0 ? 1 : 0) : 0;
        return <rect key={i} x={cx} y={cy} width={w * 0.06} height={h * 0.07} rx={3} fill={on ? '#ffd88a' : p < 1 ? '#a99886' : '#2a2e48'} />;
      })}
    </g>
  );
};

/** Общая заливка света: вечер теплее, ночью — тёмно-синяя дымка и тёплое пятно лампы */
export const LightGrade: React.FC<{t: number; lampX?: number; lampY?: number}> = ({t, lampX = 1010, lampY = 1180}) => {
  const p = dayPhase(t);
  const night = Math.max(0, p - 1);
  return (
    <g>
      <rect x={-500} y={-500} width={2100} height={2900} fill="#ff9a5a" opacity={0.1 * Math.min(1, p) * (1 - night)} style={{mixBlendMode: 'multiply'}} />
      <rect x={-500} y={-500} width={2100} height={2900} fill="#1b2350" opacity={0.42 * night} style={{mixBlendMode: 'multiply'}} />
      {night > 0 && <ellipse cx={lampX} cy={lampY} rx={420} ry={340} fill="url(#lampPool)" opacity={0.45 * night} style={{mixBlendMode: "screen"}} />}
    </g>
  );
};

/** Ноутбук: закрытый (на полке — вид спереди) */
const LaptopClosed: React.FC = () => (
  <g>
    <rect x={-115} y={-24} width={230} height={24} rx={6} fill="#8d95a6" />
    <rect x={-115} y={-24} width={230} height={8} rx={4} fill="#a9b0bf" />
    <rect x={-110} y={-2} width={220} height={4} rx={2} fill="#5d6577" />
    <rect x={40} y={-21} width={34} height={14} rx={3} fill="#ffe08a" opacity={0.9} />
    {/* пыль */}
    {[-90, -60, -20, 10, 60, 95].map((x, i) => <circle key={i} cx={x} cy={-25 + (i % 2)} r={2 + (i % 3)} fill="#d8d2c4" opacity={0.8} />)}
  </g>
);

/** Ноутбук на столе — вид на заднюю крышку (экран к герою). lid 0..1 — открыт */
const LaptopBack: React.FC<{lid: number; led: number; screen: number}> = ({lid, led, screen}) => {
  const hgt = 30 + 190 * lid;
  return (
    <g>
      <ellipse cx={0} cy={4} rx={150} ry={14} fill="#000" opacity={0.15} />
      <rect x={-140} y={-16} width={280} height={18} rx={6} fill="#7d8597" />
      {screen > 0.05 && <ellipse cx={0} cy={-hgt} rx={240} ry={140} fill="#cfe2ff" opacity={0.35 * screen} filter="url(#blur18)" />}
      <path d={`M-135 -14 L135 -14 L${125} ${-14 - hgt} L-125 ${-14 - hgt}Z`} fill="#959daf" stroke="#6d7588" strokeWidth={3} />
      <rect x={-20} y={-14 - hgt * 0.55 - 14} width={40} height={28} rx={8} fill="#b7becd" opacity={lid} />
      <circle cx={120} cy={-6} r={4} fill={led ? '#5fe39a' : '#4a5263'} />
    </g>
  );
};

/** Комната: окно, полка со старым ноутбуком, часы, стол, лампа, кровать-угол. hero: 'stand' | 'sit' | 'none' */
export const Room: React.FC<{t: number; hero?: 'stand' | 'sit' | 'none'; shelfHidden?: boolean}> = ({t, hero = 'sit'}) => {
  const frame = useCurrentFrame();
  const ls = laptopState(t);
  const night = Math.max(0, dayPhase(t) - 1);
  const clockMin = clockMinutes(t);
  return (
    <g>
      <rect x={-500} y={-500} width={2100} height={2900} fill="#efe1c6" />
      <rect x={-500} y={0} width={2100} height={ROOM.floor} fill="url(#wallG)" />
      <rect x={-500} y={ROOM.floor - 30} width={2100} height={30} fill="#fffaf0" />
      <rect x={-500} y={ROOM.floor} width={2100} height={900} fill="url(#floorG)" />
      {Array.from({length: 9}).map((_, i) => <path key={i} d={`M${-400 + i * 200} ${ROOM.floor} L${-600 + i * 260} 2400`} stroke="#a77a4e" strokeWidth={3} opacity={0.4} />)}
      <ellipse cx={420} cy={1800} rx={420} ry={90} fill={PAL.greenSoft} opacity={0.85} />
      <ellipse cx={420} cy={1800} rx={340} ry={66} fill="none" stroke="#fff" strokeWidth={6} opacity={0.6} />
      {/* окно */}
      <g>
        <rect x={50} y={300} width={430} height={660} rx={14} fill="#fffaf0" />
        <Sky t={t} x={70} y={320} w={390} h={620} />
        <rect x={262} y={320} width={8} height={620} fill="#fffaf0" />
        <rect x={70} y={600} width={390} height={8} fill="#fffaf0" />
        <rect x={40} y={950} width={450} height={26} rx={6} fill="#fffaf0" />
        {/* занавески */}
        <path d="M20 280 Q60 620 30 1000 L-40 1000 L-40 280Z" fill={PAL.green} opacity={0.85} />
        <path d="M510 280 Q470 620 500 1000 L560 1000 L560 280Z" fill={PAL.green} opacity={0.85} />
        <rect x={0} y={268} width={560} height={14} rx={7} fill={PAL.woodDark} />
        {/* растение */}
        <g transform="translate(400 950)">
          <path d="M-30 0 L30 0 L22 -54 L-22 -54Z" fill="#e88f5a" />
          {[-40, -15, 10, 35].map((a, i) => <ellipse key={i} cx={Math.sin((a * Math.PI) / 180) * 50} cy={-90 - (i % 2) * 20} rx={18} ry={42} transform={`rotate(${a} ${Math.sin((a * Math.PI) / 180) * 50} ${-90 - (i % 2) * 20})`} fill={i % 2 ? '#3fb77a' : '#2e9a63'} />)}
        </g>
      </g>
      {/* солнечное пятно днём / тёплое вечером */}
      <ellipse cx={330} cy={1690} rx={360} ry={90} fill="url(#sunPool)" opacity={Math.max(0, 1 - dayPhase(t))} />
      <ellipse cx={330} cy={1690} rx={380} ry={100} fill="url(#eveningPool)" opacity={Math.max(0, Math.min(1, dayPhase(t)) - night)} />
      {/* настенные часы */}
      <WallClock x={790} y={320} r={78} minutes={clockMin} />
      {/* полка */}
      <rect x={600} y={640} width={430} height={18} rx={4} fill={PAL.woodDark} />
      {[[620, '#e35d5b', 120], [650, '#4a78c2', 140], [684, '#f2b632', 110], [712, '#3fb77a', 130]].map(([x, c, h], i) => (
        <rect key={i} x={x as number} y={640 - (h as number)} width={26} height={h as number} rx={3} fill={c as string} />
      ))}
      <g transform="translate(860 640)">{ls.onShelf && <LaptopClosed />}{!ls.onShelf && <rect x={-115} y={-3} width={230} height={3} fill="#d8d2c4" opacity={0.7} />}</g>
      <path d="M980 640 q10 -40 -6 -70 q30 20 24 70" fill={PAL.green} />
      {/* фото/постер на стене */}
      <rect x={560} y={760} width={150} height={190} rx={8} fill="#fffaf0" stroke="#e0d2b8" strokeWidth={4} />
      <rect x={574} y={774} width={122} height={130} rx={4} fill="#9fd6ff" />
      <path d="M574 904 L620 840 L650 880 L670 860 L696 904Z" fill={PAL.green} />
      {/* стул за героем */}
      <path d={`M${ROOM.sitX - 130} 1340 L${ROOM.sitX - 120} 1090 Q${ROOM.sitX} 1050 ${ROOM.sitX + 120} 1090 L${ROOM.sitX + 130} 1340Z`} fill={PAL.blue} />
      <rect x={ROOM.sitX - 150} y={1180} width={18} height={160} rx={9} fill="#8f98ab" /><rect x={ROOM.sitX + 132} y={1180} width={18} height={160} rx={9} fill="#8f98ab" />
      <path d={`M${ROOM.sitX - 96} 1110 Q${ROOM.sitX} 1080 ${ROOM.sitX + 96} 1110 L${ROOM.sitX + 90} 1150 Q${ROOM.sitX} 1124 ${ROOM.sitX - 90} 1150Z`} fill="#6f9be0" />
      {hero === 'sit' && <SittingHero t={t} />}
      {/* стол */}
      <rect x={500} y={ROOM.deskTop} width={600} height={34} rx={8} fill="url(#deskG)" />
      <rect x={520} y={ROOM.deskTop + 34} width={560} height={ROOM.floor - ROOM.deskTop - 34} fill="#d3a97c" />
      <rect x={560} y={ROOM.deskTop + 70} width={220} height={90} rx={10} fill="#dcb68a" stroke="#b98f62" strokeWidth={3} />
      <rect x={650} y={ROOM.deskTop + 108} width={40} height={10} rx={5} fill="#8f6a44" />
      <rect x={540} y={ROOM.deskTop + 34} width={520} height={10} fill="#b98f62" opacity={0.5} />
      {/* лампа, кружка, блокнот */}
      <g transform={`translate(1040 ${ROOM.deskTop})`}>
        <rect x={-40} y={-10} width={80} height={10} rx={4} fill={PAL.greenDeep} />
        <path d="M0 -10 L-16 -150 L40 -200" stroke={PAL.greenDeep} strokeWidth={8} fill="none" />
        <path d="M10 -230 L80 -180 L50 -150 Z" fill={PAL.green} />
        <circle cx={60} cy={-165} r={10} fill={night > 0 ? '#fff4c8' : '#e7efe3'} />
      </g>
      {night > 0 && <path d="M1100 -1 L1100 0" />}
      <g transform={`translate(560 ${ROOM.deskTop})`}><rect x={-26} y={-58} width={52} height={58} rx={10} fill="#fffaf0" stroke="#d9cfbd" strokeWidth={3} /><path d="M26 -46 q22 0 22 16 q0 16 -22 16" stroke="#d9cfbd" strokeWidth={6} fill="none" /><rect x={-26} y={-40} width={52} height={10} fill={PAL.green} /></g>
      <g transform={`translate(745 ${ROOM.deskTop})`}><path d="M-60 0 L-48 -14 L56 -14 L66 0Z" fill={PAL.blue} /><rect x={-60} y={0} width={126} height={6} rx={2} fill={PAL.blueDeep} /></g>
      {/* ноутбук на столе */}
      {ls.onDesk && <g transform={`translate(${LAPTOP_DESK.x} ${LAPTOP_DESK.y})`}><LaptopBack lid={ls.lid} led={ls.led} screen={ls.screen} /></g>}
      {/* телефон на столе */}
      {hero === 'sit' && deskPose(t).phone === 'desk' && <g transform={`translate(${PHONE_DESK.x} ${PHONE_DESK.y})`}><PhoneOnDesk lit={phoneLit(t)} t={t} /></g>}
      {hero === 'stand' && <StandingHero t={t} where="room" x={ROOM.standX} />}
      <LightGrade t={t} />
      {frame < 0 && null}
    </g>
  );
};

/** минуты на часах: обычный ход, «Прошёл час» — стрелка делает полный круг; ночью — без пяти одиннадцать */
export const clockMinutes = (t: number) => {
  const base = 14 * 60 + 10;
  if (t < C.hour) return base + t / 60;
  if (t < C.evening) return base + 60 * sm(t, C.hour, C.hour + 2.0) + (t - C.hour) / 60;
  if (t < C.clock - 0.5) return 19 * 60 + 40 + (t - C.evening) / 2;
  return 22 * 60 + 56 + (t - C.clock) / 60;
};

export const WallClock: React.FC<{x: number; y: number; r: number; minutes: number}> = ({x, y, r, minutes}) => {
  const mA = ((minutes % 60) / 60) * 360, hA = (((minutes / 60) % 12) / 12) * 360;
  return (
    <g transform={`translate(${x} ${y})`}>
      <circle r={r + 8} fill={PAL.blue} />
      <circle r={r} fill="#fffaf0" />
      {Array.from({length: 12}).map((_, i) => <rect key={i} x={-3} y={-r + 8} width={6} height={i % 3 === 0 ? 18 : 10} rx={3} fill={PAL.ink} transform={`rotate(${i * 30})`} />)}
      <rect x={-5} y={-r * 0.5} width={10} height={r * 0.55} rx={5} fill={PAL.ink} transform={`rotate(${hA})`} />
      <rect x={-3.5} y={-r * 0.8} width={7} height={r * 0.85} rx={3.5} fill={PAL.ink} transform={`rotate(${mA})`} />
      <circle r={8} fill={PAL.green} />
    </g>
  );
};

const phoneItem = (where: string, armR: number, elbowR: number, t: number) => {
  const wr = armR - 90 + elbowR;
  if (where === 'hand') return <PhoneInFist worldRot={wr} lit={1} />;
  if (where === 'ear') return <PhoneAtEar worldRot={wr} />;
  return undefined;
};

/** Сидящий за столом герой (ноги скрыты столом) */
export const SittingHero: React.FC<{t: number}> = ({t}) => {
  const p = deskPose(t);
  const y = ROOM.deskTop + 55 - 140 * (1 - p.sit);
  return (
    <Hero id="hs" x={ROOM.sitX} y={y + p.bob} anchor={[505, 575]} legs={false} {...HERO_STYLE}
      armL={p.armL} elbowL={p.elbowL} armR={p.armR} elbowR={p.elbowR} itemR={phoneItem(p.phone, p.armR, p.elbowR, t)}
      face={p.face} face2={p.face2} faceMix={p.faceMix} look={p.look} turn={p.turn} tilt={p.tilt} blinkSeed={7} />
  );
};

export const StandingHero: React.FC<{t: number; where: 'room' | 'kitchen'; x: number; floor?: number}> = ({t, where, x, floor = 1800}) => {
  const p = standPose(t, where);
  return (
    <Hero id={`st-${where}`} x={x} y={floor} anchor={[505, 930]} legs {...HERO_STYLE}
      armL={p.armL} elbowL={p.elbowL} armR={p.armR} elbowR={p.elbowR} itemR={<PhoneInFist worldRot={p.armR - 90 + p.elbowR} lit={1} />}
      face={p.face} face2={p.face2} faceMix={p.faceMix} look={p.look} turn={p.turn} tilt={p.tilt} blinkSeed={7} />
  );
};

export const FRIDGE = {x: 120, y: 500, w: 400, h: 1120};

/** Кухня: холодильник слева (открыт — дверца ушла влево за кадр), герой справа от него, шкафы и плитка за героем */
export const Kitchen: React.FC<{t: number; hero?: boolean}> = ({t, hero = true}) => {
  const o = fridgeOpen(t);
  const {x: FX, y: FY, w: FW, h: FH} = FRIDGE;
  return (
    <g>
      <rect x={-500} y={-500} width={2100} height={2900} fill="#f2e6cf" />
      <rect x={-500} y={0} width={2100} height={1620} fill="url(#wallG)" />
      <rect x={520} y={880} width={1100} height={360} fill="#cfeee0" />
      {Array.from({length: 22}).map((_, i) => <path key={i} d={`M${520 + i * 50} 880 V1240`} stroke="#b3dcc8" strokeWidth={3} />)}
      {Array.from({length: 7}).map((_, i) => <path key={i} d={`M520 ${880 + i * 50} H1620`} stroke="#b3dcc8" strokeWidth={3} />)}
      <rect x={540} y={420} width={1060} height={400} rx={10} fill={PAL.blue} />
      {[560, 820, 1080].map((x, i) => <g key={i}><rect x={x} y={440} width={230} height={360} rx={10} fill="#5a87cf" /><rect x={x + 18} y={600} width={12} height={60} rx={6} fill="#fffaf0" /></g>)}
      <rect x={530} y={1240} width={1080} height={40} rx={6} fill="#fffaf0" />
      <rect x={540} y={1280} width={1060} height={340} fill="#e8dcc4" />
      {[560, 820, 1080].map((x, i) => <rect key={i} x={x} y={1300} width={230} height={300} rx={10} fill="#f4ead6" stroke="#d9cbb0" strokeWidth={3} />)}
      {/* чайник и растение на столешнице */}
      <g transform="translate(1000 1240)"><path d="M-50 0 L50 0 L40 -90 Q0 -110 -40 -90Z" fill={PAL.green} /><path d="M50 -60 q30 0 30 30" stroke={PAL.greenDeep} strokeWidth={8} fill="none" /></g>
      <rect x={-500} y={1620} width={2100} height={900} fill="#d9c7a6" />
      {Array.from({length: 10}).map((_, i) => <path key={i} d={`M${-500 + i * 220} 1620 L${-700 + i * 300} 2400`} stroke="#c4b08c" strokeWidth={3} />)}
      {/* холодильник */}
      <rect x={FX} y={FY} width={FW} height={FH} rx={30} fill="#fffaf3" stroke="#d8d0c0" strokeWidth={4} />
      <rect x={FX + 18} y={FY + 18} width={FW - 36} height={FH - 36} rx={20} fill="#fff7de" />
      {[260, 520, 760].map((y, i) => <rect key={i} x={FX + 26} y={FY + y} width={FW - 52} height={10} rx={4} fill="#d9eef5" />)}
      <FridgeContents x={FX} y={FY} />
      <ellipse cx={FX + FW / 2} cy={FY + 120} rx={170} ry={60} fill="#fffef4" opacity={0.85} filter="url(#blur18)" />
      {/* дверца закрывается поверх (только если не открыта) */}
      {o < 0.99 && <rect x={FX} y={FY} width={FW * (1 - o)} height={FH} rx={30} fill="#fffaf3" stroke="#d8d0c0" strokeWidth={4} />}
      {o > 0.01 && <path d={`M${FX} ${FY} L${FX - 150 * o} ${FY + 40 * o} L${FX - 150 * o} ${FY + FH - 40 * o} L${FX} ${FY + FH}Z`} fill="#f4efe4" stroke="#d8d0c0" strokeWidth={4} />}
      {o > 0 && <ellipse cx={FX + FW + 260} cy={1250} rx={560} ry={640} fill="url(#fridgeLight)" opacity={0.5 * o} style={{mixBlendMode: 'screen'}} />}
      {hero && <StandingHero t={t} where="kitchen" x={760} floor={1800} />}
      <LightGrade t={t} lampX={-2000} />
    </g>
  );
};

/** Крупно: рука закрывает дверцу холодильника */
export const FridgeCloseCU: React.FC<{t: number}> = ({t}) => {
  const o = fridgeOpen(t);
  const edge = 120 + 760 * o;
  return (
    <g>
      <rect width={1080} height={1920} fill="#fff7de" />
      {[620, 1080].map((y, i) => <rect key={i} x={60} y={y} width={960} height={16} rx={6} fill="#d9eef5" />)}
      <g transform="translate(-290 -40) scale(2.2)"><FridgeContents x={120} y={180} /></g>
      <ellipse cx={540} cy={420} rx={420} ry={180} fill="#fffef4" opacity={0.8} filter="url(#blur18)" />
      {/* дверца входит слева и закрывает */}
      <rect x={-40} y={0} width={1080 - edge + 40} height={1920} fill="#fffaf3" stroke="#d8d0c0" strokeWidth={8} transform={`translate(${-(1080 - edge) + (1080 - edge)} 0)`} />
      <rect x={-40} y={0} width={Math.max(0, 1080 - edge)} height={1920} fill="#e8dfcf" />
      <rect x={Math.max(0, 1080 - edge) - 26} y={0} width={26} height={1920} fill="#c9bfae" />
      <rect x={Math.max(0, 1080 - edge)} y={0} width={30} height={1920} fill="#000" opacity={0.12} />
      <rect x={Math.max(0, 1080 - edge) - 70} y={760} width={22} height={300} rx={11} fill="#c9ced8" />
      {/* ладонь толкает край дверцы, рукав — справа за кадром */}
      <g transform={`translate(${Math.max(0, 1080 - edge) + 30} 900)`}>
        <path d="M60 -70 L1200 -150 L1200 170 L60 90Z" fill="#5470a6" />
        <rect x={40} y={-80} width={70} height={180} rx={24} fill="#445f95" />
        <path d="M-40 -60 Q-70 0 -40 70 L50 80 L50 -70Z" fill={SKIN_C} stroke="#d49a6e" strokeWidth={4} />
        {[-50, -15, 20, 55].map((y, i) => <rect key={i} x={-90} y={y - 12} width={70} height={26} rx={13} fill={SKIN_C} stroke="#d49a6e" strokeWidth={3} />)}
      </g>
    </g>
  );
};
const SKIN_C = '#f3c292';

/** Содержимое холодильника — только два яйца и половина лимона */
export const FridgeContents: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g>
    {/* лоток с двумя яйцами */}
    <g transform={`translate(${x + 110} ${y + 520})`}>
      <path d="M-70 0 L70 0 L62 -26 L-62 -26Z" fill="#e9e1cf" stroke="#cfc4ad" strokeWidth={3} />
      <ellipse cx={-28} cy={-46} rx={24} ry={30} fill="#fbf3e4" stroke="#e2d6bf" strokeWidth={3} />
      <ellipse cx={26} cy={-46} rx={24} ry={30} fill="#f6e7cf" stroke="#e2d6bf" strokeWidth={3} />
    </g>
    {/* половина лимона на блюдце */}
    <g transform={`translate(${x + 250} ${y + 760})`}>
      <ellipse cx={0} cy={0} rx={70} ry={14} fill="#fffaf0" stroke="#ddd3c0" strokeWidth={3} />
      <path d="M-46 -6 A46 46 0 0 1 46 -6Z" fill="#f6d33c" stroke="#d6ad1d" strokeWidth={3} />
      <path d="M-38 -8 A38 38 0 0 1 38 -8Z" fill="#fff3a8" />
      {[-60, -30, 0, 30, 60].map((a, i) => <path key={i} d={`M0 -8 L${Math.sin((a * Math.PI) / 180) * 34} ${-8 - Math.cos((a * Math.PI) / 180) * 34}`} stroke="#f0d35a" strokeWidth={3} />)}
    </g>
  </g>
);

/** Прихожая: дверь, вешалка. heroMode: leave — герой у двери, back — вернулся с пакетом */
export const Hall: React.FC<{t: number; mode: 'leave' | 'back' | 'food1' | 'food2'}> = ({t, mode}) => {
  const doorOpen = mode === 'leave' ? sm(t, C.shop + 0.2, C.shop + 0.9) : mode === 'back' ? 1 - sm(t, C.home + 0.05, C.home + 0.7) : 0;
  const heroX = 560;
  const aL = mode === 'back' ? reach('L', 410, 650, 1) : reach('L', 404, 664, 1);
  const aR = mode === 'leave' ? reach('R', lerp(606, 690, sm(t, C.shop, C.shop + 0.25)), lerp(664, 600, sm(t, C.shop, C.shop + 0.25)), 1) : reach('R', 606, 664, 1);
  return (
    <g>
      <rect x={-500} y={-500} width={2100} height={2900} fill="#efe1c6" />
      <rect x={-500} y={0} width={2100} height={1600} fill="url(#wallG)" />
      <rect x={-500} y={1600} width={2100} height={900} fill="url(#floorG)" />
      {/* дверь */}
      <rect x={300} y={520} width={480} height={1080} rx={10} fill="#fffaf0" />
      <rect x={326} y={546} width={428} height={1054} fill="#eadbbf" />
      <rect x={326} y={546} width={428} height={1054} fill="#d8ecff" opacity={doorOpen} />
      <path d={`M326 546 L${326 + 428 * (1 - 0.82 * doorOpen)} ${546 + 40 * doorOpen} L${326 + 428 * (1 - 0.82 * doorOpen)} ${1600 - 40 * doorOpen} L326 1600Z`} fill={PAL.blue} stroke={PAL.blueDeep} strokeWidth={4} />
      <circle cx={326 + 428 * (1 - 0.82 * doorOpen) - 40} cy={1080} r={14} fill="#f2b632" opacity={1 - doorOpen * 0.8} />
      {/* вешалка */}
      <rect x={-60} y={640} width={300} height={16} rx={6} fill={PAL.woodDark} />
      {[0, 120, 220].map((x, i) => <circle key={i} cx={-30 + x} cy={672} r={10} fill="#8f6a44" />)}
      <path d="M-50 672 Q-90 900 -60 1080 L60 1080 Q80 900 30 672Z" fill="#e3a84a" />
      <path d="M180 672 Q140 820 160 940 L240 940 Q250 820 210 672Z" fill={PAL.green} />
      {/* коврик и обувь */}
      <rect x={340} y={1610} width={400} height={50} rx={14} fill={PAL.greenSoft} />
      <ellipse cx={900} cy={1680} rx={60} ry={18} fill="#3b3f52" /><ellipse cx={980} cy={1690} rx={60} ry={18} fill="#3b3f52" />
      {(mode === 'food1' || mode === 'food2') && <DeliveryPile t={t} second={mode === 'food2'} />}
      {mode === 'leave' && <Hero id="hall1" x={heroX} y={1800} anchor={[505, 930]} legs {...HERO_STYLE} armL={aL.arm} elbowL={aL.elbow} armR={aR.arm} elbowR={aR.elbow}
        face="focused" look={[0.6, 0]} turn={0.4} blinkSeed={7} />}
      {mode === 'back' && <Hero id="hall2" x={heroX} y={1800} anchor={[505, 930]} legs {...HERO_STYLE} armL={aL.arm} elbowL={aL.elbow} armR={aR.arm} elbowR={aR.elbow}
        itemL={<BagInFist worldRot={90 - aL.arm - aL.elbow} />} face="tired" look={[0, 0.3]} turn={0} blinkSeed={7} />}
      <LightGrade t={t} lampX={-2000} />
    </g>
  );
};

/** Пакеты доставки у двери: второй заказ «снова» ложится сверху */
const DeliveryPile: React.FC<{t: number; second: boolean}> = ({t, second}) => {
  const drop = (start: number) => {
    const u = sm(t, start, start + 0.35);
    return {y: -360 * (1 - u), sq: u >= 1 ? 1 - 0.08 * Math.max(0, Math.sin((t - start - 0.35) * 30)) * Math.exp(-(t - start - 0.35) * 8) : 1};
  };
  const d1 = drop(C.food1 + 0.25);
  const d2 = drop(C.food2 + 0.3);
  const Bag = ({x, y, sq, c}: {x: number; y: number; sq: number; c: string}) => (
    <g transform={`translate(${x} ${y}) scale(1 ${sq})`}>
      <path d="M-90 0 L90 0 L80 -230 L-80 -230Z" fill="#e8c9a0" stroke="#c5a274" strokeWidth={4} />
      <path d="M-80 -230 L80 -230 L70 -260 L-70 -260Z" fill="#d9b88c" />
      <circle cx={0} cy={-120} r={42} fill={c} />
      <path d="M-18 -126 Q0 -150 18 -126Z M-20 -122 h40 v6 h-40Z M-18 -110 h36 v8 h-36Z" fill="#fff" />
      <text x={0} y={-50} textAnchor="middle" fontFamily="Manrope" fontWeight={800} fontSize={26} fill="#8a6a44">ДОСТАВКА</text>
    </g>
  );
  return (
    <g>
      <g transform="translate(940 1640) scale(1.05)">
        <rect x={-150} y={-60} width={170} height={60} rx={6} fill="#f2b632" stroke="#c98f1a" strokeWidth={3} />
        <rect x={-140} y={-110} width={150} height={50} rx={6} fill="#f6c95a" stroke="#c98f1a" strokeWidth={3} />
      </g>
      <Bag x={900} y={1640 + (second ? 0 : d1.y)} sq={second ? 1 : d1.sq} c="#ff8a4c" />
      {second && <Bag x={1010} y={1680 + d2.y} sq={d2.sq} c="#e35d5b" />}
    </g>
  );
};

/** Одежда, купленная «на когда-нибудь»: на стойке, с бирками */
export const Wardrobe: React.FC<{t: number}> = ({t}) => {
  const swing = (k: number) => Math.sin(t * 2.2 + k) * 6;
  return (
    <g>
      <rect x={-500} y={-500} width={2100} height={2900} fill="#efe1c6" />
      <rect x={-500} y={0} width={2100} height={1600} fill="url(#wallG)" />
      <rect x={-500} y={1600} width={2100} height={900} fill="url(#floorG)" />
      <rect x={140} y={560} width={800} height={18} rx={9} fill="#8f98ab" />
      <rect x={150} y={578} width={14} height={1022} fill="#8f98ab" /><rect x={916} y={578} width={14} height={1022} fill="#8f98ab" />
      {[[270, '#9b6cf0', 'shirt'], [500, '#f2b632', 'jacket'], [730, PAL.blue, 'hoodie']].map(([x, c, kind], k) => (
        <g key={k} transform={`translate(${x} 578) rotate(${swing(k) * 0.3})`}>
          <path d="M0 0 q-14 0 -14 14 q0 10 14 16" stroke="#555" strokeWidth={5} fill="none" />
          <path d="M-110 50 L-40 30 Q0 60 40 30 L110 50 L140 200 L90 210 L84 480 L-84 480 L-90 210 L-140 200Z" fill={c as string} />
          <path d="M-40 30 Q0 90 40 30" stroke="#00000022" strokeWidth={6} fill="none" />
          {/* бирка без цены */}
          <g transform={`translate(70 120) rotate(${swing(k)})`}>
            <path d="M0 0 L0 50" stroke="#777" strokeWidth={2} />
            <rect x={-26} y={50} width={52} height={80} rx={6} fill="#fffaf0" stroke="#bbb" strokeWidth={2} />
            <circle cx={0} cy={60} r={5} fill="#ccc" />
            {[0, 1, 2, 3, 4, 5, 6].map((i) => <rect key={i} x={-18 + i * 5.5} y={92} width={i % 2 ? 2 : 3.5} height={26} fill="#333" />)}
          </g>
        </g>
      ))}
      {/* коробка с кроссовками */}
      <g transform="translate(560 1600)">
        <rect x={-180} y={-120} width={360} height={120} rx={8} fill="#e35d5b" />
        <rect x={-190} y={-150} width={380} height={40} rx={8} fill="#c94947" transform={`rotate(${-8} 190 -130)`} />
        <path d="M-120 -120 q40 -60 130 -40 q40 10 50 40Z" fill="#fffaf0" stroke="#ddd" strokeWidth={3} />
      </g>
      <LightGrade t={t} lampX={-2000} />
    </g>
  );
};

/** Магазин: стеллажи с простыми продуктами, герой с корзинкой */
export const Store: React.FC<{t: number}> = ({t}) => {
  const aL = reach('L', 404, 640, 1), aR = reach('R', 606, 664, 1);
  const prods = ['#e2b36d', '#f6d65a', '#fdfbf3', '#9fd6ff', '#f2b632', '#c6f0b8', '#ffb3a0'];
  return (
    <g>
      <rect x={-500} y={-500} width={2100} height={2900} fill="#eef4f6" />
      <rect x={-500} y={1620} width={2100} height={900} fill="#dfe6e8" />
      {Array.from({length: 10}).map((_, i) => <path key={i} d={`M${-500 + i * 220} 1620 L${-700 + i * 300} 2400`} stroke="#cdd6d9" strokeWidth={3} />)}
      {[0, 1, 2, 3, 4].map((i) => <rect key={i} x={-300 + i * 340} y={120} width={240} height={26} rx={13} fill="#fffef4" />)}
      <rect x={-200} y={380} width={1500} height={1240} fill="#fffaf3" stroke="#d9e2e6" strokeWidth={6} />
      {[620, 900, 1180, 1460].map((y, r) => (
        <g key={r}>
          <rect x={-200} y={y} width={1500} height={20} fill="#c9d6dc" />
          {Array.from({length: 14}).map((_, i) => {
            const c = prods[(i + r * 3) % prods.length];
            const h = 120 + ((i * 37 + r * 11) % 80);
            return <rect key={i} x={-180 + i * 105} y={y - h} width={88} height={h} rx={10} fill={c} stroke="#00000018" strokeWidth={3} />;
          })}
          {Array.from({length: 7}).map((_, i) => <rect key={i} x={-160 + i * 210} y={y + 22} width={60} height={26} rx={4} fill={PAL.green} />)}
        </g>
      ))}
      <Hero id="store" x={420} y={1820} anchor={[505, 930]} legs {...HERO_STYLE} armL={aL.arm} elbowL={aL.elbow} armR={aR.arm} elbowR={aR.elbow}
        itemL={<BasketInFist worldRot={90 - aL.arm - aL.elbow} />} face="focused" look={[0.7, -0.2]} turn={0.45} blinkSeed={7} />
    </g>
  );
};

export const _n = num;
