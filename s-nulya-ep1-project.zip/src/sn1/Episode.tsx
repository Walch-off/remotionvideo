import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, continueRender, delayRender} from 'remotion';
import {C, CI, FPS, W, H, TOTAL, WORDS, sm, win} from './story';
import {Defs, Room, Kitchen, Hall, Wardrobe, Store, FRIDGE, FridgeCloseCU} from './Sets';
import {PhoneCU, BankScreen, HistoryScreen, SubScreen, NotesScreen, CallScreen, DeadlineScreen, ScamScreen, CafeAdScreen, GalleryScreen, CafeChat, chatThumb, SW, SH} from './Phone';
import {HookShot, ShelfCU, PowerCU, ScreenCU, ClockCU, PhoneSilentCU, ToBeContinued} from './Shots';
import {ROOM} from './state';

/** начало фразы: слово с индексом CI[name] − back */
const ws = (name: string, back = 0) => WORDS[CI[name] - back].s;

type Cam = [number, number, number];
type ShotDef = {id: string; a: number; render: (t: number, a: number, b: number) => React.ReactNode};
const cam = (from: Cam, to: Cam = from) => (node: (t: number) => React.ReactNode) => (t: number, a: number, b: number) => {
  const u = sm(t, a, b);
  const [cx, cy, s] = [0, 1, 2].map((i) => from[i] + (to[i] - from[i]) * u);
  return <g transform={`translate(540 960) scale(${s}) translate(${-cx} ${-cy})`}>{node(t)}</g>;
};
const room = (hero: 'stand' | 'sit' | 'none') => (t: number) => <Room t={t} hero={hero} />;
const kitchen = (t: number) => <Kitchen t={t} />;
const phone = (screen: (t: number) => React.ReactNode, thumb?: (t: number) => {pos: [number, number] | null; press: number}) => (t: number) => {
  const th = thumb ? thumb(t) : {pos: null, press: 0};
  const bg = t >= C.clock - 0.5 ? 'night' : t >= C.evening - 0.5 ? 'evening' : 'day';
  return <PhoneCU thumb={th.pos} press={th.press} bg={bg as any} dark={false}>{screen(t)}</PhoneCU>;
};
const scrollThumb = (t: number) => ({pos: [300 + 30 * Math.sin(t * 2), 700 - ((t * 140) % 260)] as [number, number], press: 0.3});
const tapAt = (x: number, y: number, at: number) => (t: number) => ({pos: [x, y] as [number, number], press: win(t, at - 0.12, at - 0.04, at + 0.06, at + 0.2)});

const DESK_MED: Cam = [800, 1180, 1.5];
const DESK_FACE: Cam = [840, 1050, 2.45];
const DESK_FACE2: Cam = [840, 1040, 2.65];
const STAND_FACE: Cam = [ROOM.standX, 1090, 2.5];

const SHOTS_RAW: [string, number, ShotDef['render']][] = [
  ['hook', 0, (t) => <HookShot t={t} />],
  ['bank', C.three, (t) => phone((tt) => <BankScreen t={tt} />)(t)],
  ['react', C.rent, cam(STAND_FACE, [ROOM.standX, 1085, 2.65])(room('stand'))],
  ['roomWide', ws('looked', 1), cam([520, 1180, 0.95], [500, 1170, 1.0])(room('stand'))],
  ['history', ws('remember', 1), (t) => phone((tt) => <HistoryScreen t={tt} />, scrollThumb)(t)],
  ['food1', ws('food1'), cam([930, 1420, 1.55], [940, 1430, 1.62])((t) => <Hall t={t} mode="food1" />)],
  ['clothes', ws('clothes', 1), cam([540, 1060, 0.98], [540, 1040, 1.04])((t) => <Wardrobe t={t} />)],
  ['food2', ws('food2', 1), cam([950, 1420, 1.5], [950, 1430, 1.58])((t) => <Hall t={t} mode="food2" />)],
  ['subForgot', ws('sub', 2), (t) => phone((tt) => <SubScreen t={tt} mode="forgot" />)(t)],
  ['kitchen', ws('fridge'), cam([600, 1160, 0.92], [610, 1150, 0.97])(kitchen)],
  ['fridgeIn', ws('eggs', 3), cam([FRIDGE.x + FRIDGE.w / 2, 1040, 2.0], [FRIDGE.x + FRIDGE.w / 2, 1060, 2.15])(kitchen)],
  ['kFace', ws('first'), cam([760, 1080, 2.5], [760, 1075, 2.7])(kitchen)],
  ['fridgeClose', ws('because'), (t) => <FridgeCloseCU t={t} />],
  ['sit', ws('sat', 1), cam([780, 1150, 1.25], DESK_MED)(room('sit'))],
  ['notes', ws('notes'), (t) => phone((tt) => <NotesScreen t={tt} />, (tt) => ({pos: [180 + 200 * ((Math.floor(tt * 8) % 4) / 3), 860], press: tt > C.wrote && tt < C.sum ? 0.5 + 0.5 * Math.sin(tt * 30) : 0}))(t)],
  ['stare', ws('stare'), cam(DESK_FACE, DESK_FACE2)(room('sit'))],
  ['cancel', ws('cancel', 1), (t) => phone((tt) => <SubScreen t={tt} mode="cancel" />, tapAt(SW - 104, 448, C.cancel + 0.7))(t)],
  ['putDown', ws('putAway'), cam(DESK_MED, [820, 1170, 1.55])(room('sit'))],
  ['calling', C.call + 0.4, (t) => phone((tt) => <CallScreen t={tt} />)(t)],
  ['talk', ws('voice'), cam(DESK_FACE, [845, 1040, 2.6])(room('sit'))],
  ['agreed', ws('agreed', 1), cam(DESK_MED)(room('sit'))],
  ['deadline', ws('onlyWeek'), (t) => phone((tt) => <DeadlineScreen t={tt} />)(t)],
  ['search', ws('search', 1), cam([820, 1170, 1.45], [820, 1160, 1.55])(room('sit'))],
  ['scam', ws('ad1'), (t) => phone((tt) => <ScamScreen t={tt} />, tapAt(SW / 2, 960, C.perfect + 0.2))(t)],
  ['risk', ws('risk'), cam(DESK_FACE, DESK_FACE2)(room('sit'))],
  ['cafeAd', ws('ad2'), (t) => phone((tt) => <CafeAdScreen t={tt} />)(t)],
  ['notDesigner', ws('notDesigner', 1), cam(DESK_FACE)(room('sit'))],
  ['shelf', ws('friends', 3), cam([860, 610, 3.1], [860, 615, 3.4])(room('sit'))],
  ['gallery', ws('found', 1), (t) => phone((tt) => <GalleryScreen t={tt} />, (tt) => {
    const k = [0, 1, 2].findIndex((i) => tt < C.chose + 0.15 + i * 0.42 + 0.2);
    const pos = [[24 + 176 * 1 + 80, 210 + 236 + 110], [24 + 80, 210 + 110], [24 + 176 + 80, 210 + 472 + 110]][k < 0 ? 2 : k] as [number, number];
    return {pos, press: [0, 1, 2].reduce((a, i) => Math.max(a, win(tt, C.chose + 0.05 + i * 0.42, C.chose + 0.12 + i * 0.42, C.chose + 0.2 + i * 0.42, C.chose + 0.3 + i * 0.42)), 0)};
  })(t)],
  ['compose', ws('wrote2', 1), (t) => phone((tt) => <CafeChat t={tt} />, (tt) => chatThumb(tt) ?? {pos: null, press: 0})(t)],
  ['reread', ws('reread', 1), cam(DESK_FACE, DESK_FACE2)(room('sit'))],
  ['deleteAsk', ws('delete', 3), (t) => phone((tt) => <CafeChat t={tt} />, (tt) => chatThumb(tt) ?? {pos: null, press: 0})(t)],
  ['hour', ws('hour'), cam([600, 900, 1.05], [600, 880, 1.1])(room('sit'))],
  ['leave', ws('shop', 1), cam([540, 1150, 1.0])((t) => <Hall t={t} mode="leave" />)],
  ['store', ws('bought'), cam([500, 1200, 1.15], [520, 1180, 1.2])((t) => <Store t={t} />)],
  ['back', ws('home', 1), cam([560, 1200, 1.15])((t) => <Hall t={t} mode="back" />)],
  ['silent', ws('silent', 3), (t) => <PhoneSilentCU t={t} />],
  ['evening', ws('evening', 1), cam([760, 1120, 1.2], [800, 1150, 1.4])(room('sit'))],
  ['reply', ws('hello'), (t) => phone((tt) => <CafeChat t={tt} />)(t)],
  ['smile', ws('smiled', 1), cam(DESK_FACE, [840, 1035, 2.75])(room('sit'))],
  ['reply2', ws('another', 1), (t) => phone((tt) => <CafeChat t={tt} />)(t)],
  ['clock', ws('clock', 3), (t) => <ClockCU t={t} />],
  ['shelfTake', ws('thenLaptop', 1), (t) => <ShelfCU t={t} />],
  ['deskNight', C.laptop + 1.3, cam([720, 1170, 1.45])(room('sit'))],
  ['power', ws('press', 1), (t) => <PowerCU t={t} />],
  ['screen', ws('blink', 1), (t) => <ScreenCU t={t} />],
  ['hours', ws('hours', 2), cam(DESK_FACE, DESK_FACE2)(room('sit'))],
  ['final', ws('q'), cam([700, 1150, 1.3], [600, 1150, 1.0])(room('sit'))],
];
export const SHOTS = SHOTS_RAW.map(([id, a, render], i) => ({id, a, b: i + 1 < SHOTS_RAW.length ? SHOTS_RAW[i + 1][1] : C.end, render}));

/** общая цветокоррекция: чисто и тепло, без пересвета */
const GRADE: React.CSSProperties = {filter: 'saturate(1.08) contrast(1.03)'};

const ShotView: React.FC<{s: (typeof SHOTS)[number]; from: number}> = ({s, from}) => {
  const frame = useCurrentFrame();
  const t = (from + frame) / FPS;
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={GRADE}>
      <Defs />
      <defs>
        <linearGradient id="cardSheen" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#fff" /><stop offset="1" stopColor="#fff" stopOpacity={0} /></linearGradient>
        <linearGradient id="screenSheen" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#fff" stopOpacity={0.18} /><stop offset="0.5" stopColor="#fff" stopOpacity={0} /></linearGradient>
      </defs>
      {s.render(t, s.a, s.b)}
      <rect width={W} height={H} fill="url(#softVig)" />
    </svg>
  );
};

// ---------- субтитры ----------
/** убираем кавычки и скобки любого вида — слова не трогаем */
export const cleanWord = (w: string) => w.replace(/[«»"“”„'‘’()[\]{}]/g, '');
type Chunk = {words: {text: string; s: number; e: number; i: number}[]; s: number; e: number};
const ACCENT = new Set(['триста', 'три', 'дня', 'две', 'недели', 'неделю.', 'неделю', 'семь', 'дней,', 'отправить.', 'утру.', 'одиннадцать']);
export const CHUNKS: Chunk[] = (() => {
  const out: Chunk[] = [];
  let cur: Chunk['words'] = [];
  const flush = () => { if (cur.length) out.push({words: cur, s: cur[0].s, e: cur[cur.length - 1].e}); cur = []; };
  WORDS.forEach((w, i) => {
    const text = cleanWord(w.text);
    const len = cur.reduce((a, c) => a + c.text.length + 1, 0) + text.length;
    const prev = cur[cur.length - 1];
    if (cur.length && (len > 36 || cur.length >= 6 || (cur.length >= 2 && /[,:—]$/.test(prev.text)) || (prev && w.s - prev.e > 0.45))) flush();
    cur.push({text, s: w.s, e: w.e, i});
    if (/[.?!…]$/.test(text)) flush();
  });
  flush();
  return out;
})();

const Subtitles: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const idx = CHUNKS.findIndex((c, k) => {
    const next = CHUNKS[k + 1];
    return t >= c.s - 0.08 && t < Math.min(c.e + 0.45, next ? next.s - 0.08 : 1e9);
  });
  if (idx < 0) return null;
  const c = CHUNKS[idx];
  const text = c.words.map((x) => x.text).join(' ');
  let lines = [c.words];
  if (text.length > 21 && c.words.length > 1) {
    let best = 1, bestD = 1e9;
    for (let k = 1; k < c.words.length; k++) {
      const a = c.words.slice(0, k).map((x) => x.text).join(' ').length, b = c.words.slice(k).map((x) => x.text).join(' ').length;
      const d = Math.abs(a - b) + (a > 24 || b > 24 ? 100 : 0);
      if (d < bestD) { bestD = d; best = k; }
    }
    lines = [c.words.slice(0, best), c.words.slice(best)];
  }
  const next = CHUNKS[idx + 1];
  const end = Math.min(c.e + 0.45, next ? next.s - 0.08 : 1e9);
  const a = Math.min(sm(t, c.s - 0.08, c.s + 0.06), 1 - sm(t, end - 0.1, end));
  const fs = 58, lh = 80, bottom = 1585, cx = 520;
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute'}}>
      <defs><filter id="subShadow" x="-10%" y="-30%" width="120%" height="160%"><feDropShadow dx={0} dy={3} stdDeviation={4} floodColor="#0b1220" floodOpacity={0.45} /></filter></defs>
      <g opacity={a} transform={`translate(0 ${6 * (1 - a)})`}>
        {lines.map((ln, li) => {
          const y = bottom - (lines.length - 1 - li) * lh;
          const str = ln.map((x) => x.text).join(' ');
          const w = str.length * fs * 0.56 + 44;
          return (
            <g key={li}>
              <rect x={cx - w / 2} y={y - fs * 0.86} width={w} height={fs * 1.22} rx={fs * 0.4} fill="#14203a" opacity={0.42} />
              <text x={cx} y={y} textAnchor="middle" fontFamily="Manrope" fontWeight={800} fontSize={fs} filter="url(#subShadow)">
                {ln.map((x, k) => {
                  const key = x.text.toLowerCase().replace(/[!?]/g, '');
                  return <tspan key={x.i} fill={ACCENT.has(key) ? '#7ff0b0' : '#ffffff'}>{(k ? ' ' : '') + x.text}</tspan>;
                })}
              </text>
            </g>
          );
        })}
      </g>
    </svg>
  );
};

const Badge: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const a = win(t, C.rent + 0.1, C.rent + 0.5, ws('remember', 1) - 0.4, ws('remember', 1));
  if (a <= 0) return null;
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute'}}>
      <g opacity={a} transform="translate(540 250)">
        <rect x={-230} y={-40} width={460} height={80} rx={40} fill="#fffaf0" opacity={0.92} />
        <circle cx={-182} cy={0} r={18} fill="#3fb77a" />
        <text x={14} y={14} textAnchor="middle" fontFamily="Manrope" fontWeight={800} fontSize={36} fill="#1f2b45">С НУЛЯ · СЕРИЯ 1</text>
      </g>
    </svg>
  );
};

const EndCard: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute'}}>
      <ToBeContinued t={frame / FPS} />
    </svg>
  );
};

/** Шрифт Manrope (SIL OFL) из public/fonts — ждём загрузки перед рендером кадров */
const FontLoader: React.FC = () => {
  const [h] = React.useState(() => delayRender('font'));
  React.useEffect(() => {
    const f = new FontFace('Manrope', `url(${staticFile('fonts/Manrope-wght.ttf')})`, {weight: '200 800'});
    f.load().then((ff) => { (document.fonts as any).add(ff); continueRender(h); }).catch(() => continueRender(h));
  }, [h]);
  return null;
};

export const SNulya1: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#f3e9d6', fontFamily: 'Manrope'}}>
    <FontLoader />
    {SHOTS.map((s) => {
      const from = Math.round(s.a * FPS);
      const to = Math.min(TOTAL, Math.round(s.b * FPS));
      return (
        <Sequence key={s.id} from={from} durationInFrames={Math.max(1, to - from)} name={s.id}>
          <ShotView s={s} from={from} />
        </Sequence>
      );
    })}
    <Badge />
    <Subtitles />
    <EndCard />
    <Audio src={staticFile('audio/voice.wav')} volume={1} />
    <Audio src={staticFile('audio/music.wav')} volume={1} />
    <Audio src={staticFile('audio/sfx.wav')} volume={1} />
  </AbsoluteFill>
);

/** Тест: крючок (0–8 с) */
export const SNulya1TestHook: React.FC = () => <SNulya1 />;
/** Тест: рука и предметы — чат, удаление, отправка (≈106–115 с) */
export const SNulya1TestHands: React.FC = () => (
  <AbsoluteFill><Sequence from={-Math.round(ws('reread', 1) * FPS)}><SNulya1 /></Sequence></AbsoluteFill>
);
export {TOTAL, SH};
