"""«С нуля», серия 1: монтаж озвучки, таймлайн событий, синтез музыки и эффектов.

Вход:  исходный WAV (не изменяется), src/data/words_orig.json (scripts/align.py).
Выход: public/audio/{voice,sfx,music}.wav, src/data/words.json, src/data/cues.json.

Музыка и все эффекты синтезированы здесь (numpy/scipy) — сторонних треков и библиотек звуков нет.
Запуск: python scripts/build_audio.py public/audio/voice_original.wav
"""
import json, os, re, sys
import numpy as np
from scipy import signal
from scipy.io import wavfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 44100
SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, 'public/audio/voice_original.wav')
rng = np.random.default_rng(11)

sr0, v = wavfile.read(SRC)
assert sr0 == SR, sr0
v = v.astype(np.float32) / 32768.0
if v.ndim > 1:
    v = v.mean(axis=1)
words = json.load(open(os.path.join(ROOT, 'src/data/words_orig.json')))
norm = lambda x: re.sub(r'[^а-яa-z0-9]', '', x.lower().replace('ё', 'е'))


def find(token, start=0):
    for i in range(start, len(words)):
        if norm(words[i]['text']) == norm(token):
            return i
    raise KeyError(token)


def quietest(a, b):
    i0, i1 = int(a * SR), int(b * SR)
    seg = v[i0:i1] ** 2
    w = int(0.04 * SR)
    if len(seg) <= w:
        return (a + b) / 2
    e = np.convolve(seg, np.ones(w) / w, mode='valid')
    return (i0 + int(np.argmin(e)) + w // 2) / SR


def gap_after(tok, start=0):
    i = find(tok, start)
    return quietest(words[i]['e'], words[i + 1]['s'])


# короткие паузы в настоящей тишине между фразами — только там, где действию нужно время
PAUSES = sorted([
    (gap_after('наступило.'), 0.45),     # закрыл холодильник → сел за стол
    (gap_after('страшно.'), 0.35),       # закрыл переписку → следующее объявление
    (gap_after('«отправить».'), 0.5),    # отправил → ожидание
    (gap_after('погас.'), 0.6),          # экран погас — тишина
])
TAIL = 3.0


def fmap(t):
    return t + sum(d for (p, d) in PAUSES if p <= t)


parts, prev = [], 0
for p, d in PAUSES:
    parts += [v[prev:int(p * SR)], np.zeros(int(d * SR), np.float32)]
    prev = int(p * SR)
parts.append(v[prev:])
voice = np.concatenate(parts)
last_e = fmap(words[-1]['e'])
N = int((last_e + TAIL) * SR)
voice = np.pad(voice, (0, max(0, N - len(voice))))[:N]
DUR = N / SR
wout = [{'text': w['text'], 's': round(fmap(w['s']), 3), 'e': round(fmap(w['e']), 3)} for w in words]

CUES = [
    ('hook', 'На'), ('balance', 'триста'), ('three', 'три'), ('rent', 'квартиру.'), ('looked', 'смотрел'), ('remember', 'вспомнить,'),
    ('salary', 'Зарплату'), ('twoWeeks', 'две'), ('food1', 'Сначала'), ('clothes', 'купил'), ('someday', '«когда-нибудь».'),
    ('food2', 'снова'), ('sub', 'оформил'), ('forgot', 'забыл.'), ('fridge', 'И'), ('openFridge', 'открытым'), ('eggs', 'два'),
    ('lemon', 'половина'), ('first', 'Впервые'), ('nothing', '«Ничего,'), ('because', 'Потому'), ('arrived', 'наступило.'),
    ('sat', 'сел'), ('notes', 'открыл'), ('wrote', 'записал'), ('sum', 'Сумма'), ('bigger', 'больше,'), ('stare', 'Сначала'),
    ('cancel', 'выключил'), ('putAway', 'убрал'), ('call', 'позвонил'), ('voice', 'Голос'), ('explained', 'объяснил'),
    ('later', 'позже.'), ('agreed', 'согласился'), ('week', 'неделю.'), ('onlyWeek', 'Только'), ('seven', 'семь'),
    ('search', 'начал'), ('ad1', 'Одно'), ('noExp', 'опыта.'), ('perfect', 'идеально.'), ('until', 'До'), ('transfer', 'перевести'),
    ('training', '«обучение».'), ('look300', 'посмотрел'), ('closeChat', 'закрыл'), ('risk', 'Рисковать'), ('scary', 'страшно.'),
    ('ad2', 'Следующее'), ('cafe', 'кафе'), ('photos', 'фотографии'), ('notDesigner', 'не'), ('friends', 'картинки'),
    ('oldLaptop', 'старом'), ('found', 'нашёл'), ('chose', 'выбрал'), ('wrote2', 'написал'), ('reread', 'перечитал'),
    ('delete', 'удалить'), ('nothingOffer', 'Казалось,'), ('send', 'нажал'), ('sendWord', '«отправить».'), ('hour', 'Прошёл'),
    ('noAnswer', 'Ответа'), ('shop', 'сходил'), ('bought', 'купил'), ('home', 'вернулся'), ('silent', 'молчал.'),
    ('evening', 'вечером'), ('hello', '«Здравствуйте.'), ('liked', 'Ваши'), ('canShow', 'Можете'), ('smiled', 'улыбнулся.'),
    ('firstDay', 'Впервые'), ('another', 'следом'), ('need', '«Нам'), ('morning', 'утру».'), ('clock', 'часы.'), ('almost', 'почти'),
    ('thenLaptop', 'потом'), ('laptop', 'ноутбук,'), ('months', 'месяцев.'), ('press', 'нажал'), ('blink', 'мигнул…'),
    ('off', 'погас.'), ('hours', 'оставалось'), ('q', 'Получится'), ('next', 'Узнаем'),
]
cues, cidx, idx = {}, {}, 0
for name, tok in CUES:
    idx = find(tok, idx)
    cues[name] = wout[idx]['s']
    cidx[name] = idx
cues['lastWord'] = wout[-1]['e']
cues['end'] = round(DUR, 3)
cues['pauses'] = [[round(fmap(p) - d, 3), d] for p, d in PAUSES]
C = cues
json.dump(wout, open(os.path.join(ROOT, 'src/data/words.json'), 'w'), ensure_ascii=False, indent=0)
json.dump({'cues': cues, 'idx': cidx}, open(os.path.join(ROOT, 'src/data/cues.json'), 'w'), ensure_ascii=False, indent=1)

# ============================ инструменты ============================
T = np.arange(N) / SR


def lp(x, f, o=2):
    return signal.sosfilt(signal.butter(o, f, 'lowpass', fs=SR, output='sos'), x)


def hp(x, f, o=2):
    return signal.sosfilt(signal.butter(o, f, 'highpass', fs=SR, output='sos'), x)


def bp(x, lo, hi, o=2):
    return signal.sosfilt(signal.butter(o, [lo, hi], 'bandpass', fs=SR, output='sos'), x)


def noise(n):
    return rng.standard_normal(n)


def place(track, t, x, g=1.0):
    i = int(round(t * SR))
    if i < 0:
        x = x[-i:]; i = 0
    if i >= len(track):
        return
    x = x[: len(track) - i]
    track[i:i + len(x)] += g * x


def npk(x, p=1.0):
    return x / (np.max(np.abs(x)) + 1e-9) * p


def env(n, a=0.003, r=0.2):
    t = np.arange(n) / SR
    return np.minimum(1, t / max(a, 1e-4)) * np.exp(-t / r)


def tone(f, dur, decay=0.3, a=0.004):
    n = int(dur * SR); t = np.arange(n) / SR
    return np.sin(2 * np.pi * f * t) * env(n, a, decay)


# ---- эффекты ----
def tap():
    n = int(0.035 * SR)
    return npk(bp(noise(n), 1800, 6000) * env(n, 0.0005, 0.004) + 0.4 * tone(900, 0.035, 0.008))


def notif(f1=1046.5, f2=1568.0):
    x = np.zeros(int(0.7 * SR))
    for k, f in enumerate((f1, f2)):
        n = int(0.55 * SR); t = np.arange(n) / SR
        s = (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2 * f * t)) * env(n, 0.003, 0.16)
        place(x, k * 0.11, s)
    return npk(x)


def soft_bong(f=110):
    n = int(2.0 * SR); t = np.arange(n) / SR
    return npk((np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t / 0.3)) * env(n, 0.01, 0.7))


def typing(dur, rate=9.0):
    x = np.zeros(int(dur * SR)); t = 0.0
    while t < dur - 0.05:
        place(x, t, tap(), rng.uniform(0.5, 1.0))
        t += rng.uniform(0.6, 1.4) / rate
    return x


def fridge_open():
    n = int(0.6 * SR); t = np.arange(n) / SR
    pop = bp(noise(n), 300, 2500) * env(n, 0.002, 0.04)
    clink = sum(np.sin(2 * np.pi * f * t) * np.exp(-t / 0.08) for f in (2400, 3300)) * (t > 0.15) * 0.3
    return npk(pop + clink)


def fridge_close():
    n = int(0.5 * SR); t = np.arange(n) / SR
    return npk(np.sin(2 * np.pi * 70 * t) * env(n, 0.002, 0.07) + bp(noise(n), 200, 1500) * env(n, 0.001, 0.03) * 0.6)


def hum(dur):
    n = int(dur * SR); t = np.arange(n) / SR
    e = np.minimum(1, t / 0.3) * np.minimum(1, (dur - t) / 0.3)
    return (np.sin(2 * np.pi * 60 * t) * 0.4 + lp(noise(n), 250) * 0.6) * e


def thud(f=90, dur=0.25):
    n = int(dur * SR); t = np.arange(n) / SR
    return npk(np.sin(2 * np.pi * f * t) * env(n, 0.002, dur / 4) + bp(noise(n), 300, 2000) * env(n, 0.001, 0.01) * 0.4)


def ring_ru(n_rings=2):
    x = np.zeros(int((n_rings * 2.0 + 0.2) * SR))
    for k in range(n_rings):
        n = int(1.0 * SR); t = np.arange(n) / SR
        place(x, k * 2.0, np.sin(2 * np.pi * 425 * t) * np.minimum(1, t / 0.01) * np.minimum(1, (1.0 - t) / 0.01))
    return npk(x)


def click(f=2500):
    n = int(0.05 * SR)
    return npk(bp(noise(n), f * 0.6, min(f * 1.6, 16000)) * env(n, 0.0005, 0.006) + 0.5 * tone(f / 3, 0.05, 0.01))


def swoosh(dur=0.35, lo=500, hi=4000):
    n = int(dur * SR)
    return npk(bp(noise(n), lo, hi) * np.hanning(n))


def toggle():
    x = np.zeros(int(0.2 * SR))
    place(x, 0, click(3000), 1.0); place(x, 0.05, tone(660, 0.12, 0.05), 0.4)
    return npk(x)


def end_call():
    x = np.zeros(int(0.9 * SR))
    for k in range(3):
        n = int(0.15 * SR); t = np.arange(n) / SR
        place(x, k * 0.28, np.sin(2 * np.pi * 425 * t) * np.minimum(1, t / 0.005) * np.minimum(1, (0.15 - t) / 0.005))
    return npk(x)


def door(open_=True):
    x = np.zeros(int(0.9 * SR))
    place(x, 0, click(1800), 0.8)
    place(x, 0.08, metal_jingle(), 0.5)
    place(x, 0.5 if open_ else 0.3, thud(85, 0.3), 0.8 if not open_ else 0.3)
    return npk(x)


def metal_jingle():
    x = np.zeros(int(0.4 * SR))
    for _ in range(4):
        n = int(0.25 * SR); t = np.arange(n) / SR; f = rng.uniform(2600, 5200)
        place(x, rng.uniform(0, 0.15), np.sin(2 * np.pi * f * t) * np.exp(-t / 0.04), rng.uniform(0.4, 1))
    return npk(x)


def rustle(dur=0.8):
    n = int(dur * SR); t = np.arange(n) / SR
    am = 0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 7 * t + rng.uniform(0, 3)))
    return npk(bp(noise(n), 1500, 7000) * am * np.sin(np.pi * t / dur))


def beep_scan():
    return npk(tone(1900, 0.12, 0.08, 0.002))


def tick():
    return npk(bp(noise(int(0.02 * SR)), 2500, 7000) * env(int(0.02 * SR), 0.0003, 0.003))


def laptop_press():
    x = np.zeros(int(0.3 * SR)); place(x, 0, click(2000), 1.0); place(x, 0.02, thud(140, 0.12), 0.3)
    return npk(x)


def fan_up(dur=1.0):
    n = int(dur * SR); t = np.arange(n) / SR
    f = 120 + 200 * (t / dur)
    return npk(bp(noise(n), 400, 2000) * np.minimum(1, t / 0.3) * 0.5 + np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.3 * np.minimum(1, t / 0.3))


def power_down(dur=1.2):
    n = int(dur * SR); t = np.arange(n) / SR
    f = 320 * np.exp(-t / 0.35) + 40
    return npk((np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.5 + bp(noise(n), 300, 1500) * 0.4) * np.exp(-t / 0.4))


def flicker_buzz(dur=0.5):
    n = int(dur * SR); t = np.arange(n) / SR
    gate = (np.sin(2 * np.pi * 9 * t) > 0).astype(float)
    return npk(lp(signal.sawtooth(2 * np.pi * 120 * t) * gate, 1200) * np.hanning(n))


def chair():
    n = int(0.5 * SR); t = np.arange(n) / SR
    f = 200 + 80 * np.sin(2 * np.pi * 3 * t)
    return npk(bp(signal.sawtooth(2 * np.pi * np.cumsum(f) / SR), 300, 1500) * np.sin(np.pi * t / 0.5))


sfx = np.zeros(N)
place(sfx, 0.02, soft_bong(98), 0.35)                       # сдержанный акцент на крючке
place(sfx, C['three'] - 0.35, notif(880, 1318.5), 0.3)      # напоминание об оплате
place(sfx, C['remember'] + 0.3, tap(), 0.25); place(sfx, C['remember'] + 0.9, swoosh(0.25, 800, 5000), 0.15)
place(sfx, C['salary'] - 0.1, tap(), 0.25)
for k in ('food1', 'clothes', 'food2', 'sub'):
    place(sfx, C[k] + 0.05, swoosh(0.25, 600, 4000), 0.18)
place(sfx, C['food1'] + 0.3, rustle(0.5), 0.2)
place(sfx, C['food2'] + 0.3, rustle(0.5), 0.2)
place(sfx, C['fridge'] - 0.45, fridge_open(), 0.35)
place(sfx, C['fridge'] - 0.3, hum(C['arrived'] + 0.7 - C['fridge']), 0.06)
place(sfx, C['arrived'] + 0.55, fridge_close(), 0.4)
place(sfx, C['sat'] + 0.1, chair(), 0.18)
place(sfx, C['wrote'], typing(C['sum'] - C['wrote'] - 0.2), 0.2)
place(sfx, C['cancel'] + 0.7, toggle(), 0.3)
place(sfx, C['putAway'] + 0.45, thud(150, 0.15), 0.25)
place(sfx, C['call'] + 0.45, ring_ru(2), 0.12)
place(sfx, C['voice'] - 0.25, click(1500), 0.15)
place(sfx, C['onlyWeek'] + 0.9, end_call(), 0.1)
place(sfx, C['seven'] - 0.3, notif(1174.7, 1568.0), 0.25)
place(sfx, C['search'] + 0.4, tap(), 0.2); place(sfx, C['search'] + 0.9, swoosh(0.3, 800, 5000), 0.15)
place(sfx, C['ad1'] + 0.1, tap(), 0.2)
place(sfx, C['until'] + 0.5, notif(740, 622), 0.22)          # сообщение «об оплате обучения» — ниже, настороженно
place(sfx, C['closeChat'] + 0.3, swoosh(0.35, 400, 3000), 0.25)
place(sfx, C['ad2'] + 0.1, tap(), 0.2)
for k in range(3):
    place(sfx, C['chose'] + 0.15 + k * 0.42, tap(), 0.3)
place(sfx, C['wrote2'] + 0.2, typing(1.8), 0.18)
place(sfx, C['send'] + 0.75, swoosh(0.4, 1000, 6000), 0.3)
place(sfx, C['send'] + 0.75, tap(), 0.3)
for k in range(12):
    place(sfx, C['hour'] + k * 0.17, tick(), 0.18)
place(sfx, C['shop'] + 0.1, door(True), 0.3)
place(sfx, C['bought'] + 0.35, beep_scan(), 0.12)
place(sfx, C['home'] + 0.1, door(False), 0.3)
place(sfx, C['home'] + 0.6, rustle(0.9), 0.25)
place(sfx, C['evening'] + 0.5, notif(), 0.35)
place(sfx, C['another'] + 0.1, notif(), 0.3)
for k in range(6):
    place(sfx, C['clock'] - 0.2 + k * 1.0, tick(), 0.25)
place(sfx, C['laptop'] - 0.4, thud(120, 0.2), 0.2)
place(sfx, C['laptop'] + 1.2, click(1400), 0.25)
place(sfx, C['press'] + 0.55, laptop_press(), 0.35)
place(sfx, C['press'] + 0.7, fan_up(1.2), 0.12)
place(sfx, C['blink'] - 0.05, flicker_buzz(0.5), 0.12)
place(sfx, C['off'] - 0.05, power_down(1.2), 0.25)
place(sfx, C['q'] - 0.2, soft_bong(87.3), 0.25)

# ============================ музыка ============================
# Тёплый лоу-фай: электропиано, мягкий пэд, бас, тихая ритм-секция. Секции и уровни следуют сюжету.
NOTE = lambda name: 440 * 2 ** ((
    {'C': -9, 'C#': -8, 'Db': -8, 'D': -7, 'Eb': -6, 'E': -5, 'F': -4, 'F#': -3, 'G': -2, 'Ab': -1, 'A': 0, 'Bb': 1, 'B': 2}[name[:-1]]
    + 12 * (int(name[-1]) - 4)) / 12)
CH = {
    'Am9': ['A2', 'E3', 'G3', 'B3', 'C4'], 'Fmaj7': ['F2', 'C3', 'E3', 'A3'], 'Dm7': ['D2', 'C3', 'F3', 'A3'], 'Esus': ['E2', 'D3', 'E3', 'A3'],
    'Cmaj7': ['C3', 'E3', 'G3', 'B3'], 'G6': ['G2', 'D3', 'E3', 'B3'], 'Em7': ['E2', 'D3', 'G3', 'B3'], 'Fmaj9': ['F2', 'E3', 'G3', 'A3', 'C4'],
    'Am7': ['A2', 'E3', 'G3', 'C4'], 'Dm9': ['D2', 'F3', 'A3', 'C4', 'E4'], 'Bbmaj7': ['Bb2', 'D3', 'F3', 'A3'],
}
BPM = 82
BAR = 4 * 60 / BPM
TENSE = ['Am9', 'Fmaj7', 'Dm7', 'Esus']
CALM = ['Fmaj7', 'Em7', 'Dm7', 'Cmaj7']
HOPE = ['Fmaj9', 'G6', 'Em7', 'Am7']
NIGHT = ['Dm9', 'Bbmaj7', 'Am7', 'Esus']


def section(t):
    if t < C['salary']: return TENSE
    if t < C['fridge']: return CALM
    if t < C['sat']: return TENSE
    if t < C['agreed']: return TENSE
    if t < C['search']: return CALM
    if t < C['ad2']: return TENSE
    if t < C['evening']: return CALM
    if t < C['another']: return HOPE
    if t < C['clock']: return CALM
    return NIGHT


def ep_note(f, dur):
    n = int(dur * SR); t = np.arange(n) / SR
    mod = 1.6 * np.exp(-t / 0.25) * np.sin(2 * np.pi * f * t)
    x = np.sin(2 * np.pi * f * t + mod) * np.exp(-t / 1.4) + 0.25 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t / 0.5)
    return x * np.minimum(1, t / 0.006) * (1 + 0.06 * np.sin(2 * np.pi * 4.5 * t))


def pad_chord(names, dur):
    n = int(dur * SR); t = np.arange(n) / SR
    x = sum(sum(signal.sawtooth(2 * np.pi * NOTE(nm) * (1 + d) * t + rng.uniform(0, 6)) for d in (-0.003, 0.003)) for nm in names[1:])
    e = np.minimum(1, t / 0.8) * np.clip((dur - t) / 0.8, 0, 1)
    return lp(x, 900) * e


ep = np.zeros(N); pad = np.zeros(N); bass = np.zeros(N); drums = np.zeros(N); bells = np.zeros(N)
bar = 0
t0 = 0.0
while t0 < DUR:
    prog = section(t0)
    ch = CH[prog[bar % 4]]
    # электропиано: аккорд на «раз» и мягкая синкопа
    for k, nm in enumerate(ch[1:]):
        place(ep, t0 + 0.012 * k, ep_note(NOTE(nm), BAR * 0.9), 0.5)
    for k, nm in enumerate(ch[2:]):
        place(ep, t0 + BAR * 0.625 + 0.01 * k, ep_note(NOTE(nm), BAR * 0.4), 0.25)
    place(pad, t0, pad_chord(ch, BAR + 0.8), 1.0)
    # бас
    for bt, ln in ((0, 0.45), (0.5, 0.3), (0.75, 0.2)):
        n = int(BAR * ln * SR); tt = np.arange(n) / SR; f = NOTE(ch[0])
        place(bass, t0 + bt * BAR, np.tanh(1.5 * np.sin(2 * np.pi * f * tt)) * env(n, 0.01, BAR * ln * 0.6), 1.0)
    # ритм: мягкая бочка, щелчок, шейкер
    beat = 60 / BPM
    for b in range(4):
        tb = t0 + b * beat
        if b in (0, 2):
            n = int(0.3 * SR); tt = np.arange(n) / SR
            place(drums, tb, np.sin(2 * np.pi * (50 + 60 * np.exp(-tt / 0.03)) * tt) * env(n, 0.001, 0.12), 1.0)
        if b in (1, 3):
            place(drums, tb, bp(noise(int(0.08 * SR)), 1500, 5000) * env(int(0.08 * SR), 0.001, 0.025), 0.35)
        for h in (0, 0.5):
            place(drums, tb + h * beat, hp(noise(int(0.04 * SR)), 7000) * env(int(0.04 * SR), 0.001, 0.01), 0.18)
    # колокольчики надежды
    if prog is HOPE:
        for k, nm in enumerate(ch[1:]):
            f = NOTE(nm) * 4
            place(bells, t0 + k * beat * 0.5 + beat, tone(f, 1.2, 0.5), 0.5)
    t0 += BAR
    bar += 1


def lev(keys):
    ts, vs = zip(*keys)
    return np.interp(T, ts, vs)


c = C
L_ep = lev([(0, 0.55), (c['fridge'], 0.5), (c['first'], 0.2), (c['arrived'], 0.0), (c['sat'] + 0.6, 0.35), (c['agreed'], 0.5), (c['transfer'], 0.2),
            (c['scary'], 0.15), (c['ad2'], 0.5), (c['delete'], 0.3), (c['sendWord'], 0.0), (c['hour'], 0.45), (c['evening'], 0.6), (c['another'], 0.5),
            (c['clock'], 0.35), (c['press'], 0.15), (c['off'], 0.0), (c['hours'], 0.0), (c['q'], 0.4), (DUR - 1.2, 0.3), (DUR, 0.0)])
L_pad = lev([(0, 0.5), (c['first'], 0.35), (c['arrived'], 0.2), (c['training'], 0.55), (c['ad2'], 0.35), (c['evening'], 0.4), (c['off'], 0.0),
             (c['hours'], 0.45), (DUR - 1.0, 0.35), (DUR, 0.0)])
L_bass = lev([(0, 0.0), (c['twoWeeks'], 0.0), (c['salary'] + 1, 0.5), (c['fridge'], 0.0), (c['sat'] + 1, 0.4), (c['search'], 0.5), (c['transfer'], 0.15),
              (c['ad2'], 0.5), (c['sendWord'], 0.0), (c['hour'], 0.5), (c['clock'], 0.3), (c['press'], 0.0), (DUR, 0.0)])
L_drum = lev([(0, 0.0), (c['salary'], 0.0), (c['salary'] + 1, 0.35), (c['fridge'], 0.0), (c['search'], 0.0), (c['search'] + 1, 0.3), (c['until'], 0.0),
              (c['hour'], 0.0), (c['hour'] + 0.6, 0.45), (c['silent'], 0.3), (c['evening'], 0.45), (c['another'], 0.2), (c['clock'], 0.0), (DUR, 0.0)])
L_bell = lev([(0, 0), (c['hello'], 0.0), (c['liked'], 0.6), (c['another'], 0.6), (c['another'] + 0.5, 0.0), (DUR, 0)])


def unit(x):
    return x / (np.sqrt(np.mean(x ** 2)) + 1e-9)

music = unit(ep) * L_ep * 0.9 + unit(pad) * L_pad * 0.45 + unit(bass) * L_bass * 0.55 + unit(drums) * L_drum * 0.45 + unit(bells) * L_bell * 0.35
music = lp(music, 6500)
music *= np.clip(T / 0.6, 0, 1) * np.clip((DUR - T) / 2.0, 0, 1)

# ============================ сведение ============================
venv = np.abs(voice)
w = int(0.05 * SR)
venv = lp(np.convolve(venv, np.ones(w) / w, mode='same'), 4)
speech = np.clip(venv / 0.03, 0, 1)
duck = 1 - 0.45 * speech


def peak_db(x, db):
    return npk(x, 10 ** (db / 20))

MASTER = 10 ** (3.0 / 20)
stems = {'voice': voice, 'sfx': peak_db(sfx, -9) * (0.75 + 0.25 * duck), 'music': peak_db(music, -12) * duck}
stems = {k: x * MASTER for k, x in stems.items()}
for k, x in stems.items():
    assert np.max(np.abs(x)) < 0.99, (k, float(np.max(np.abs(x))))
mix = sum(stems.values())
os.makedirs(os.path.join(ROOT, 'public/audio'), exist_ok=True)
for k, x in stems.items():
    wavfile.write(os.path.join(ROOT, f'public/audio/{k}.wav'), SR, (np.clip(x, -1, 1) * 32767).astype(np.int16))
print(json.dumps({'duration': round(DUR, 3), 'pauses': PAUSES, 'mix_peak_dbfs': round(20 * np.log10(np.max(np.abs(mix)) + 1e-9), 2)}))
