// Проверка субтитров: после очистки не осталось кавычек, скобок и эмоциональных тегов; слова не перекрываются по времени.
// node scripts/check_subs.mjs
import fs from 'fs';
const words = JSON.parse(fs.readFileSync('src/data/words.json', 'utf8'));
const clean = (w) => w.replace(/[«»"“”„'‘’()[\]{}]/g, '');
const shown = words.map((w) => clean(w.text));
const bad = shown.filter((s) => /[«»"“”„'‘’()[\]{}]|tense|quietly|hopeful/i.test(s));
const overlaps = words.slice(1).filter((w, i) => w.s < words[i].e - 0.05).length;
const lost = words.filter((w) => clean(w.text).replace(/[^а-яёa-z0-9]/gi, '') === '').length;
console.log(JSON.stringify({words: words.length, forbidden: bad.length, emptyAfterClean: lost, overlaps}));
